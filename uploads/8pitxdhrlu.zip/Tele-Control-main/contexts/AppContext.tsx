import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '@/constants/config';
import { telegramApi, BotInfo, TelegramUpdate, TelegramMessage } from '@/services/telegramApi';
import { encryptToken, decryptToken } from '@/services/encryption';

export interface AutoReplyRule {
  id: string;
  keyword: string;
  reply: string;
  enabled: boolean;
}

export interface ActivityLogEntry {
  id: string;
  type: 'send' | 'receive' | 'broadcast' | 'auto_reply' | 'system';
  message: string;
  timestamp: number;
  details?: string;
}

interface AppContextType {
  // Token & Bot
  token: string | null;
  botInfo: BotInfo | null;
  isLoading: boolean;
  setTokenAndSave: (token: string, info: BotInfo) => Promise<void>;
  clearToken: () => Promise<void>;
  
  // Messages
  messages: TelegramUpdate[];
  fetchMessages: () => Promise<void>;
  isFetchingMessages: boolean;
  
  // Auto Reply
  autoReplyEnabled: boolean;
  toggleAutoReply: () => Promise<void>;
  autoReplyRules: AutoReplyRule[];
  addAutoReplyRule: (keyword: string, reply: string) => Promise<void>;
  removeAutoReplyRule: (id: string) => Promise<void>;
  toggleAutoReplyRule: (id: string) => Promise<void>;
  
  // Broadcast
  broadcastIds: string[];
  addBroadcastId: (id: string) => Promise<void>;
  removeBroadcastId: (id: string) => Promise<void>;
  
  // Activity Log
  activityLog: ActivityLogEntry[];
  addLog: (type: ActivityLogEntry['type'], message: string, details?: string) => Promise<void>;
  clearLog: () => Promise<void>;
  
  // PIN
  pinEnabled: boolean;
  pinCode: string | null;
  setPinCode: (pin: string | null) => Promise<void>;
  togglePin: () => Promise<void>;
  isPinLocked: boolean;
  unlockWithPin: (pin: string) => boolean;
  
  // Stats
  messagesSentCount: number;
  incrementMessagesSent: () => void;
}

const AppContext = createContext<AppContextType>({} as AppContextType);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [botInfo, setBotInfo] = useState<BotInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [messages, setMessages] = useState<TelegramUpdate[]>([]);
  const [isFetchingMessages, setIsFetchingMessages] = useState(false);
  const [autoReplyEnabled, setAutoReplyEnabled] = useState(false);
  const [autoReplyRules, setAutoReplyRules] = useState<AutoReplyRule[]>([]);
  const [broadcastIds, setBroadcastIds] = useState<string[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [pinEnabled, setPinEnabled] = useState(false);
  const [pinCode, setPinCodeState] = useState<string | null>(null);
  const [isPinLocked, setIsPinLocked] = useState(false);
  const [messagesSentCount, setMessagesSentCount] = useState(0);
  const lastUpdateId = useRef<number | undefined>(undefined);

  // Load all data on mount
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      const [
        encryptedToken,
        savedBotInfo,
        savedAutoReplyEnabled,
        savedAutoReplyRules,
        savedBroadcastIds,
        savedLog,
        savedPinEnabled,
        savedPinCode,
        savedLastUpdateId,
      ] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.BOT_TOKEN),
        AsyncStorage.getItem(STORAGE_KEYS.BOT_INFO),
        AsyncStorage.getItem(STORAGE_KEYS.AUTO_REPLY_ENABLED),
        AsyncStorage.getItem(STORAGE_KEYS.AUTO_REPLY_RULES),
        AsyncStorage.getItem(STORAGE_KEYS.BROADCAST_IDS),
        AsyncStorage.getItem(STORAGE_KEYS.ACTIVITY_LOG),
        AsyncStorage.getItem(STORAGE_KEYS.PIN_ENABLED),
        AsyncStorage.getItem(STORAGE_KEYS.PIN_CODE),
        AsyncStorage.getItem(STORAGE_KEYS.LAST_UPDATE_ID),
      ]);

      if (encryptedToken) {
        const decrypted = decryptToken(encryptedToken);
        setToken(decrypted);
        telegramApi.setToken(decrypted);
      }
      if (savedBotInfo) setBotInfo(JSON.parse(savedBotInfo));
      if (savedAutoReplyEnabled) setAutoReplyEnabled(JSON.parse(savedAutoReplyEnabled));
      if (savedAutoReplyRules) setAutoReplyRules(JSON.parse(savedAutoReplyRules));
      if (savedBroadcastIds) setBroadcastIds(JSON.parse(savedBroadcastIds));
      if (savedLog) setActivityLog(JSON.parse(savedLog));
      if (savedPinEnabled) {
        const enabled = JSON.parse(savedPinEnabled);
        setPinEnabled(enabled);
        if (enabled) setIsPinLocked(true);
      }
      if (savedPinCode) setPinCodeState(savedPinCode);
      if (savedLastUpdateId) lastUpdateId.current = Number(savedLastUpdateId);
    } catch (e) {
      console.error('Failed to load data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const setTokenAndSave = async (newToken: string, info: BotInfo) => {
    const encrypted = encryptToken(newToken);
    await AsyncStorage.setItem(STORAGE_KEYS.BOT_TOKEN, encrypted);
    await AsyncStorage.setItem(STORAGE_KEYS.BOT_INFO, JSON.stringify(info));
    setToken(newToken);
    setBotInfo(info);
    telegramApi.setToken(newToken);
    addLog('system', 'Token configured', `Bot: @${info.username}`);
  };

  const clearToken = async () => {
    await AsyncStorage.multiRemove([STORAGE_KEYS.BOT_TOKEN, STORAGE_KEYS.BOT_INFO]);
    setToken(null);
    setBotInfo(null);
    setMessages([]);
    telegramApi.setToken('');
    addLog('system', 'Token cleared');
  };

  const fetchMessages = useCallback(async () => {
    if (!token || isFetchingMessages) return;
    setIsFetchingMessages(true);
    try {
      const result = await telegramApi.getUpdates(undefined, 100);
      if (result.ok && result.result) {
        const filtered = result.result.filter(u => u.message);
        setMessages(filtered);
        if (filtered.length > 0) {
          const maxId = Math.max(...filtered.map(u => u.update_id));
          lastUpdateId.current = maxId;
          await AsyncStorage.setItem(STORAGE_KEYS.LAST_UPDATE_ID, String(maxId));
        }
        
        // Process auto-reply
        if (autoReplyEnabled && autoReplyRules.length > 0) {
          for (const update of filtered) {
            if (update.message?.text) {
              const msgText = update.message.text.toLowerCase();
              for (const rule of autoReplyRules) {
                if (rule.enabled && msgText.includes(rule.keyword.toLowerCase())) {
                  await telegramApi.sendMessage(
                    String(update.message.chat.id),
                    rule.reply
                  );
                  addLog('auto_reply', `Auto-replied to ${update.message.from?.first_name || 'Unknown'}`, `Keyword: "${rule.keyword}"`);
                  break;
                }
              }
            }
          }
        }
      }
    } catch (e) {
      console.error('Fetch messages error:', e);
    } finally {
      setIsFetchingMessages(false);
    }
  }, [token, autoReplyEnabled, autoReplyRules, isFetchingMessages]);

  const toggleAutoReply = async () => {
    const newVal = !autoReplyEnabled;
    setAutoReplyEnabled(newVal);
    await AsyncStorage.setItem(STORAGE_KEYS.AUTO_REPLY_ENABLED, JSON.stringify(newVal));
    addLog('system', `Auto-reply ${newVal ? 'enabled' : 'disabled'}`);
  };

  const addAutoReplyRule = async (keyword: string, reply: string) => {
    const newRule: AutoReplyRule = {
      id: Date.now().toString(),
      keyword,
      reply,
      enabled: true,
    };
    const updated = [...autoReplyRules, newRule];
    setAutoReplyRules(updated);
    await AsyncStorage.setItem(STORAGE_KEYS.AUTO_REPLY_RULES, JSON.stringify(updated));
  };

  const removeAutoReplyRule = async (id: string) => {
    const updated = autoReplyRules.filter(r => r.id !== id);
    setAutoReplyRules(updated);
    await AsyncStorage.setItem(STORAGE_KEYS.AUTO_REPLY_RULES, JSON.stringify(updated));
  };

  const toggleAutoReplyRule = async (id: string) => {
    const updated = autoReplyRules.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r);
    setAutoReplyRules(updated);
    await AsyncStorage.setItem(STORAGE_KEYS.AUTO_REPLY_RULES, JSON.stringify(updated));
  };

  const addBroadcastId = async (id: string) => {
    if (broadcastIds.includes(id)) return;
    const updated = [...broadcastIds, id];
    setBroadcastIds(updated);
    await AsyncStorage.setItem(STORAGE_KEYS.BROADCAST_IDS, JSON.stringify(updated));
  };

  const removeBroadcastId = async (id: string) => {
    const updated = broadcastIds.filter(i => i !== id);
    setBroadcastIds(updated);
    await AsyncStorage.setItem(STORAGE_KEYS.BROADCAST_IDS, JSON.stringify(updated));
  };

  const addLog = async (type: ActivityLogEntry['type'], message: string, details?: string) => {
    const entry: ActivityLogEntry = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: Date.now(),
      details,
    };
    setActivityLog(prev => {
      const updated = [entry, ...prev].slice(0, 200);
      AsyncStorage.setItem(STORAGE_KEYS.ACTIVITY_LOG, JSON.stringify(updated));
      return updated;
    });
  };

  const clearLog = async () => {
    setActivityLog([]);
    await AsyncStorage.setItem(STORAGE_KEYS.ACTIVITY_LOG, JSON.stringify([]));
  };

  const setPinCode = async (pin: string | null) => {
    if (pin) {
      setPinCodeState(pin);
      await AsyncStorage.setItem(STORAGE_KEYS.PIN_CODE, pin);
    } else {
      setPinCodeState(null);
      await AsyncStorage.removeItem(STORAGE_KEYS.PIN_CODE);
    }
  };

  const togglePin = async () => {
    const newVal = !pinEnabled;
    setPinEnabled(newVal);
    await AsyncStorage.setItem(STORAGE_KEYS.PIN_ENABLED, JSON.stringify(newVal));
    if (!newVal) {
      setIsPinLocked(false);
    }
  };

  const unlockWithPin = (pin: string): boolean => {
    if (pin === pinCode) {
      setIsPinLocked(false);
      return true;
    }
    return false;
  };

  const incrementMessagesSent = () => {
    setMessagesSentCount(prev => prev + 1);
  };

  return (
    <AppContext.Provider
      value={{
        token, botInfo, isLoading, setTokenAndSave, clearToken,
        messages, fetchMessages, isFetchingMessages,
        autoReplyEnabled, toggleAutoReply, autoReplyRules,
        addAutoReplyRule, removeAutoReplyRule, toggleAutoReplyRule,
        broadcastIds, addBroadcastId, removeBroadcastId,
        activityLog, addLog, clearLog,
        pinEnabled, pinCode, setPinCode, togglePin, isPinLocked, unlockWithPin,
        messagesSentCount, incrementMessagesSent,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
