import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSequence,
  Easing,
  runOnJS,
} from 'react-native-reanimated';
import { theme } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';
import { useApp } from '@/contexts/AppContext';

const { width } = Dimensions.get('window');

export default function SplashScreen() {
  const router = useRouter();
  const { token, botInfo, isLoading, isPinLocked } = useApp();
  
  const logoScale = useSharedValue(0.3);
  const logoOpacity = useSharedValue(0);
  const titleOpacity = useSharedValue(0);
  const titleTranslateY = useSharedValue(20);
  const subtitleOpacity = useSharedValue(0);
  const loadingOpacity = useSharedValue(0);
  const loadingWidth = useSharedValue(0);

  useEffect(() => {
    // Animate in
    logoScale.value = withTiming(1, { duration: 800, easing: Easing.out(Easing.back(1.5)) });
    logoOpacity.value = withTiming(1, { duration: 600 });
    titleOpacity.value = withDelay(400, withTiming(1, { duration: 500 }));
    titleTranslateY.value = withDelay(400, withTiming(0, { duration: 500 }));
    subtitleOpacity.value = withDelay(600, withTiming(1, { duration: 500 }));
    loadingOpacity.value = withDelay(800, withTiming(1, { duration: 300 }));
    loadingWidth.value = withDelay(800, withTiming(width * 0.5, { duration: 2000, easing: Easing.inOut(Easing.quad) }));
  }, []);

  useEffect(() => {
    if (isLoading) return;
    
    const timer = setTimeout(() => {
      if (!token || !botInfo) {
        router.replace('/setup');
      } else if (isPinLocked) {
        router.replace('/pin-lock');
      } else {
        router.replace('/(tabs)');
      }
    }, APP_CONFIG.splashDuration);
    
    return () => clearTimeout(timer);
  }, [isLoading, token, botInfo, isPinLocked]);

  const logoAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: logoScale.value }],
    opacity: logoOpacity.value,
  }));

  const titleAnimStyle = useAnimatedStyle(() => ({
    opacity: titleOpacity.value,
    transform: [{ translateY: titleTranslateY.value }],
  }));

  const subtitleAnimStyle = useAnimatedStyle(() => ({
    opacity: subtitleOpacity.value,
  }));

  const loadingBarAnimStyle = useAnimatedStyle(() => ({
    opacity: loadingOpacity.value,
  }));

  const loadingFillAnimStyle = useAnimatedStyle(() => ({
    width: loadingWidth.value,
  }));

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Animated.View style={[styles.logoContainer, logoAnimStyle]}>
          <Image
            source={require('@/assets/images/bot-logo.png')}
            style={styles.logo}
            contentFit="contain"
          />
        </Animated.View>
        
        <Animated.View style={titleAnimStyle}>
          <Text style={styles.appName}>{APP_CONFIG.name}</Text>
        </Animated.View>
        
        <Animated.View style={subtitleAnimStyle}>
          <Text style={styles.subtitle}>Telegram Bot Controller</Text>
        </Animated.View>
      </View>

      <Animated.View style={[styles.loadingContainer, loadingBarAnimStyle]}>
        <View style={styles.loadingTrack}>
          <Animated.View style={[styles.loadingFill, loadingFillAnimStyle]} />
        </View>
        <Text style={styles.loadingText}>Initializing...</Text>
      </Animated.View>

      <Text style={styles.version}>v{APP_CONFIG.version}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    alignItems: 'center',
  },
  logoContainer: {
    width: 130,
    height: 130,
    borderRadius: 32,
    overflow: 'hidden',
    marginBottom: 24,
    ...theme.shadows.glow,
  },
  logo: {
    width: 130,
    height: 130,
  },
  appName: {
    fontSize: 36,
    fontWeight: '700',
    color: theme.textPrimary,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    fontWeight: '500',
    color: theme.textSecondary,
    marginTop: 8,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  loadingContainer: {
    position: 'absolute',
    bottom: 120,
    alignItems: 'center',
  },
  loadingTrack: {
    width: Dimensions.get('window').width * 0.5,
    height: 3,
    backgroundColor: theme.surfaceLight,
    borderRadius: 2,
    overflow: 'hidden',
  },
  loadingFill: {
    height: 3,
    backgroundColor: theme.primary,
    borderRadius: 2,
  },
  loadingText: {
    fontSize: 12,
    color: theme.textMuted,
    marginTop: 12,
  },
  version: {
    position: 'absolute',
    bottom: 40,
    fontSize: 12,
    color: theme.textMuted,
  },
});
