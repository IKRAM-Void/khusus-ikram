import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, useSharedValue, useAnimatedStyle, withSequence, withTiming } from 'react-native-reanimated';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';
import { Image } from 'expo-image';

export default function PinLockScreen() {
  const router = useRouter();
  const { unlockWithPin } = useApp();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const shakeX = useSharedValue(0);

  const handlePress = (digit: string) => {
    if (pin.length >= 4) return;
    Haptics.selectionAsync();
    const newPin = pin + digit;
    setPin(newPin);
    setError(false);
    
    if (newPin.length === 4) {
      setTimeout(() => {
        const success = unlockWithPin(newPin);
        if (success) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          router.replace('/(tabs)');
        } else {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          setError(true);
          setPin('');
          shakeX.value = withSequence(
            withTiming(-12, { duration: 50 }),
            withTiming(12, { duration: 50 }),
            withTiming(-8, { duration: 50 }),
            withTiming(8, { duration: 50 }),
            withTiming(0, { duration: 50 })
          );
        }
      }, 200);
    }
  };

  const handleDelete = () => {
    if (pin.length === 0) return;
    Haptics.selectionAsync();
    setPin(pin.slice(0, -1));
    setError(false);
  };

  const dotsStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shakeX.value }],
  }));

  const digits = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];

  return (
    <View style={styles.container}>
      <Animated.View entering={FadeIn.duration(500)} style={styles.content}>
        <Image
          source={require('@/assets/images/bot-logo.png')}
          style={styles.logo}
          contentFit="contain"
        />
        <Text style={styles.title}>Masukkan PIN</Text>
        <Text style={styles.subtitle}>
          {error ? 'PIN salah, coba lagi' : 'Masukkan 4 digit PIN untuk membuka'}
        </Text>
        
        <Animated.View style={[styles.dots, dotsStyle]}>
          {[0, 1, 2, 3].map(i => (
            <View
              key={i}
              style={[
                styles.dot,
                pin.length > i && styles.dotFilled,
                error && styles.dotError,
              ]}
            />
          ))}
        </Animated.View>

        <View style={styles.keypad}>
          {digits.map((digit, index) => (
            <Pressable
              key={index}
              style={[styles.key, digit === '' && styles.keyEmpty]}
              onPress={() => {
                if (digit === 'del') handleDelete();
                else if (digit !== '') handlePress(digit);
              }}
              disabled={digit === ''}
            >
              {digit === 'del' ? (
                <MaterialIcons name="backspace" size={24} color={theme.textSecondary} />
              ) : (
                <Text style={styles.keyText}>{digit}</Text>
              )}
            </Pressable>
          ))}
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    width: '100%',
    paddingHorizontal: 40,
  },
  logo: {
    width: 64,
    height: 64,
    borderRadius: 16,
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    marginBottom: 32,
  },
  dots: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 48,
  },
  dot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: theme.border,
    backgroundColor: 'transparent',
  },
  dotFilled: {
    backgroundColor: theme.primary,
    borderColor: theme.primary,
  },
  dotError: {
    borderColor: theme.error,
    backgroundColor: theme.error,
  },
  keypad: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: 280,
    gap: 12,
  },
  key: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyEmpty: {
    backgroundColor: 'transparent',
  },
  keyText: {
    fontSize: 28,
    fontWeight: '500',
    color: theme.textPrimary,
  },
});
