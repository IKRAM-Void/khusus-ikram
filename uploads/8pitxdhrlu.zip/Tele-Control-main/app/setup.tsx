import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, Pressable, ScrollView,
  KeyboardAvoidingView, Platform, ActivityIndicator, Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withSpring, FadeInDown,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { telegramApi, BotInfo } from '@/services/telegramApi';
import { useApp } from '@/contexts/AppContext';

export default function SetupScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { setTokenAndSave } = useApp();
  
  const [tokenInput, setTokenInput] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedBot, setVerifiedBot] = useState<BotInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showGuide, setShowGuide] = useState(false);
  
  const cardScale = useSharedValue(1);

  const handleVerify = async () => {
    if (!tokenInput.trim()) {
      setError('Masukkan Bot Token');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    
    setIsVerifying(true);
    setError(null);
    setVerifiedBot(null);
    
    const result = await telegramApi.verifyToken(tokenInput.trim());
    
    if (result.ok && result.result) {
      setVerifiedBot(result.result);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      cardScale.value = withSpring(1.02, {}, () => {
        cardScale.value = withSpring(1);
      });
    } else {
      setError(result.error || 'Token tidak valid');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
    
    setIsVerifying(false);
  };

  const handleContinue = async () => {
    if (!verifiedBot) return;
    Haptics.selectionAsync();
    await setTokenAndSave(tokenInput.trim(), verifiedBot);
    router.replace('/(tabs)');
  };

  const cardAnimStyle = useAnimatedStyle(() => ({
    transform: [{ scale: cardScale.value }],
  }));

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 24 }]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Image
              source={require('@/assets/images/bot-logo.png')}
              style={styles.headerLogo}
              contentFit="contain"
            />
            <Text style={styles.title}>Konfigurasi Bot</Text>
            <Text style={styles.subtitle}>
              Masukkan Bot Token Telegram untuk mulai mengontrol bot Anda
            </Text>
          </View>

          <View style={styles.inputSection}>
            <Text style={styles.inputLabel}>BOT TOKEN</Text>
            <View style={[styles.inputContainer, error ? styles.inputError : null]}>
              <MaterialIcons name="vpn-key" size={20} color={theme.textMuted} />
              <TextInput
                style={styles.input}
                placeholder="1234567890:ABCdefGhIJKlmnoPQRsTUVwxyz"
                placeholderTextColor={theme.textMuted}
                value={tokenInput}
                onChangeText={(text) => {
                  setTokenInput(text);
                  setError(null);
                  setVerifiedBot(null);
                }}
                autoCapitalize="none"
                autoCorrect={false}
                selectionColor={theme.primary}
              />
            </View>
            {error && (
              <Animated.View entering={FadeInDown.duration(300)} style={styles.errorContainer}>
                <MaterialIcons name="error-outline" size={16} color={theme.error} />
                <Text style={styles.errorText}>{error}</Text>
              </Animated.View>
            )}
          </View>

          <Pressable
            style={[styles.verifyButton, isVerifying && styles.buttonDisabled]}
            onPress={handleVerify}
            disabled={isVerifying}
          >
            {isVerifying ? (
              <ActivityIndicator color="#FFF" size="small" />
            ) : (
              <>
                <MaterialIcons name="verified" size={20} color="#FFF" />
                <Text style={styles.verifyButtonText}>Verifikasi Token</Text>
              </>
            )}
          </Pressable>

          <Pressable
            style={styles.guideButton}
            onPress={() => setShowGuide(!showGuide)}
          >
            <MaterialIcons name="help-outline" size={18} color={theme.primary} />
            <Text style={styles.guideButtonText}>Cara Mendapatkan Token</Text>
            <MaterialIcons 
              name={showGuide ? 'keyboard-arrow-up' : 'keyboard-arrow-down'} 
              size={20} 
              color={theme.primary} 
            />
          </Pressable>

          {showGuide && (
            <Animated.View entering={FadeInDown.duration(300)} style={styles.guideCard}>
              <View style={styles.guideStep}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>1</Text>
                </View>
                <Text style={styles.guideText}>
                  Buka Telegram dan cari <Text style={styles.guideBold}>@BotFather</Text>
                </Text>
              </View>
              <View style={styles.guideStep}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>2</Text>
                </View>
                <Text style={styles.guideText}>
                  Kirim perintah <Text style={styles.guideBold}>/newbot</Text> untuk membuat bot baru
                </Text>
              </View>
              <View style={styles.guideStep}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>3</Text>
                </View>
                <Text style={styles.guideText}>
                  Ikuti instruksi dan berikan nama serta username bot
                </Text>
              </View>
              <View style={styles.guideStep}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>4</Text>
                </View>
                <Text style={styles.guideText}>
                  Salin token yang diberikan BotFather dan paste di sini
                </Text>
              </View>
              <Pressable
                style={styles.openTelegramButton}
                onPress={() => Linking.openURL('https://t.me/BotFather')}
              >
                <MaterialIcons name="open-in-new" size={16} color={theme.telegram} />
                <Text style={styles.openTelegramText}>Buka @BotFather</Text>
              </Pressable>
            </Animated.View>
          )}

          {verifiedBot && (
            <Animated.View style={[styles.resultCard, cardAnimStyle]} entering={FadeInDown.duration(400)}>
              <View style={styles.resultHeader}>
                <View style={styles.successBadge}>
                  <MaterialIcons name="check-circle" size={20} color={theme.success} />
                  <Text style={styles.successText}>Token Valid</Text>
                </View>
              </View>
              
              <View style={styles.botInfoGrid}>
                <View style={styles.botInfoRow}>
                  <Text style={styles.botInfoLabel}>Nama Bot</Text>
                  <Text style={styles.botInfoValue}>{verifiedBot.first_name}</Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.botInfoRow}>
                  <Text style={styles.botInfoLabel}>Username</Text>
                  <Text style={styles.botInfoValue}>@{verifiedBot.username}</Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.botInfoRow}>
                  <Text style={styles.botInfoLabel}>Bot ID</Text>
                  <Text style={styles.botInfoValue}>{verifiedBot.id}</Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.botInfoRow}>
                  <Text style={styles.botInfoLabel}>Status</Text>
                  <View style={styles.statusOnline}>
                    <View style={styles.statusDot} />
                    <Text style={styles.statusText}>Online</Text>
                  </View>
                </View>
              </View>

              <Pressable style={styles.continueButton} onPress={handleContinue}>
                <Text style={styles.continueButtonText}>Masuk ke Dashboard</Text>
                <MaterialIcons name="arrow-forward" size={20} color="#FFF" />
              </Pressable>
            </Animated.View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 32,
  },
  headerLogo: {
    width: 80,
    height: 80,
    borderRadius: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: theme.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 20,
  },
  inputSection: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 16,
    gap: 12,
  },
  inputError: {
    borderColor: theme.error,
  },
  input: {
    flex: 1,
    height: 52,
    color: theme.textPrimary,
    fontSize: 14,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
  },
  errorText: {
    fontSize: 13,
    color: theme.error,
  },
  verifyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.primary,
    borderRadius: theme.radius.medium,
    height: 52,
    gap: 8,
    marginBottom: 16,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  verifyButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFF',
  },
  guideButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    marginBottom: 8,
  },
  guideButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: theme.primary,
  },
  guideCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 20,
    borderWidth: 1,
    borderColor: theme.border,
    marginBottom: 24,
  },
  guideStep: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 16,
  },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: theme.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumberText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFF',
  },
  guideText: {
    flex: 1,
    fontSize: 14,
    color: theme.textSecondary,
    lineHeight: 20,
    paddingTop: 3,
  },
  guideBold: {
    fontWeight: '600',
    color: theme.textPrimary,
  },
  openTelegramButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 4,
    paddingVertical: 10,
    backgroundColor: 'rgba(42, 171, 238, 0.1)',
    borderRadius: theme.radius.small,
  },
  openTelegramText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.telegram,
  },
  resultCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 20,
    borderWidth: 1,
    borderColor: theme.success,
    marginTop: 8,
  },
  resultHeader: {
    marginBottom: 16,
  },
  successBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: theme.radius.full,
    alignSelf: 'flex-start',
  },
  successText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.success,
  },
  botInfoGrid: {},
  botInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  botInfoLabel: {
    fontSize: 14,
    color: theme.textSecondary,
  },
  botInfoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  divider: {
    height: 1,
    backgroundColor: theme.border,
  },
  statusOnline: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.success,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.success,
  },
  continueButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.success,
    borderRadius: theme.radius.medium,
    height: 52,
    gap: 8,
    marginTop: 20,
  },
  continueButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFF',
  },
});
