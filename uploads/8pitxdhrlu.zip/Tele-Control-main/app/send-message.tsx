import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, Pressable, ScrollView,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { telegramApi } from '@/services/telegramApi';
import { useApp } from '@/contexts/AppContext';

export default function SendMessageScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { addLog, incrementMessagesSent } = useApp();

  const [chatId, setChatId] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; text: string } | null>(null);

  const handleSend = async () => {
    if (!chatId.trim() || !message.trim()) return;
    setIsSending(true);
    setResult(null);

    const res = await telegramApi.sendMessage(chatId.trim(), message.trim());

    if (res.ok) {
      setResult({ ok: true, text: 'Pesan berhasil dikirim!' });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      addLog('send', `Pesan dikirim ke ${chatId}`, message.trim());
      incrementMessagesSent();
      setMessage('');
    } else {
      setResult({ ok: false, text: res.error || 'Gagal mengirim pesan' });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }

    setIsSending(false);
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.header}>
          <Pressable style={styles.closeButton} onPress={() => router.back()}>
            <MaterialIcons name="close" size={24} color={theme.textSecondary} />
          </Pressable>
          <Text style={styles.headerTitle}>Kirim Pesan</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 24 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.infoCard}>
            <MaterialIcons name="info-outline" size={18} color={theme.primary} />
            <Text style={styles.infoText}>
              Masukkan Chat ID tujuan dan pesan yang akan dikirim melalui bot Anda.
            </Text>
          </View>

          <Text style={styles.inputLabel}>CHAT ID</Text>
          <View style={styles.inputContainer}>
            <MaterialIcons name="tag" size={20} color={theme.textMuted} />
            <TextInput
              style={styles.input}
              placeholder="Contoh: 123456789"
              placeholderTextColor={theme.textMuted}
              value={chatId}
              onChangeText={setChatId}
              keyboardType="default"
              autoCapitalize="none"
              selectionColor={theme.primary}
            />
          </View>

          <Text style={[styles.inputLabel, { marginTop: 20 }]}>PESAN</Text>
          <View style={[styles.inputContainer, styles.messageContainer]}>
            <TextInput
              style={[styles.input, styles.messageInput]}
              placeholder="Ketik pesan Anda di sini..."
              placeholderTextColor={theme.textMuted}
              value={message}
              onChangeText={setMessage}
              multiline
              numberOfLines={6}
              textAlignVertical="top"
              selectionColor={theme.primary}
            />
          </View>
          <Text style={styles.charCount}>{message.length} karakter</Text>

          {result && (
            <Animated.View
              entering={FadeInDown.duration(300)}
              style={[styles.resultCard, result.ok ? styles.resultSuccess : styles.resultError]}
            >
              <MaterialIcons
                name={result.ok ? 'check-circle' : 'error'}
                size={20}
                color={result.ok ? theme.success : theme.error}
              />
              <Text style={[styles.resultText, { color: result.ok ? theme.success : theme.error }]}>
                {result.text}
              </Text>
            </Animated.View>
          )}

          <Pressable
            style={[styles.sendButton, isSending && styles.sendDisabled]}
            onPress={handleSend}
            disabled={isSending || !chatId.trim() || !message.trim()}
          >
            {isSending ? (
              <ActivityIndicator color="#FFF" size="small" />
            ) : (
              <>
                <MaterialIcons name="send" size={20} color="#FFF" />
                <Text style={styles.sendButtonText}>Kirim Pesan</Text>
              </>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: theme.primary + '10',
    borderRadius: theme.radius.medium,
    padding: 14,
    marginTop: 20,
    marginBottom: 24,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: theme.textSecondary,
    lineHeight: 20,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 14,
    gap: 10,
  },
  input: {
    flex: 1,
    height: 50,
    color: theme.textPrimary,
    fontSize: 15,
  },
  messageContainer: {
    alignItems: 'flex-start',
    paddingVertical: 4,
  },
  messageInput: {
    height: 140,
    paddingTop: 12,
  },
  charCount: {
    fontSize: 11,
    color: theme.textMuted,
    textAlign: 'right',
    marginTop: 6,
    marginBottom: 16,
  },
  resultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: theme.radius.medium,
    padding: 14,
    marginBottom: 16,
  },
  resultSuccess: {
    backgroundColor: theme.success + '12',
    borderWidth: 1,
    borderColor: theme.success + '30',
  },
  resultError: {
    backgroundColor: theme.error + '12',
    borderWidth: 1,
    borderColor: theme.error + '30',
  },
  resultText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
  },
  sendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: theme.primary,
    borderRadius: theme.radius.medium,
    height: 54,
  },
  sendDisabled: {
    opacity: 0.5,
  },
  sendButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFF',
  },
});
