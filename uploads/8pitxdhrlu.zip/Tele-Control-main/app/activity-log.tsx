import React from 'react';
import {
  View, Text, StyleSheet, Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import { FlashList } from '@shopify/flash-list';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { theme } from '@/constants/theme';
import { useApp, ActivityLogEntry } from '@/contexts/AppContext';

const typeConfig: Record<ActivityLogEntry['type'], { icon: string; color: string }> = {
  send: { icon: 'send', color: theme.primary },
  receive: { icon: 'mail', color: theme.telegram },
  broadcast: { icon: 'campaign', color: '#F59E0B' },
  auto_reply: { icon: 'reply', color: theme.success },
  system: { icon: 'settings', color: theme.textMuted },
};

export default function ActivityLogScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { activityLog, clearLog } = useApp();

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const mins = Math.floor(diff / 60000);
    
    if (mins < 1) return 'Baru saja';
    if (mins < 60) return `${mins}m lalu`;
    if (mins < 1440) return `${Math.floor(mins / 60)}j lalu`;
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  const renderItem = ({ item, index }: { item: ActivityLogEntry; index: number }) => {
    const config = typeConfig[item.type] || typeConfig.system;
    return (
      <View style={styles.logItem}>
        <View style={[styles.logIcon, { backgroundColor: config.color + '18' }]}>
          <MaterialIcons name={config.icon as any} size={18} color={config.color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.logMessage}>{item.message}</Text>
          {item.details && (
            <Text style={styles.logDetails} numberOfLines={1}>{item.details}</Text>
          )}
        </View>
        <Text style={styles.logTime}>{formatTime(item.timestamp)}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <Pressable style={styles.backButton} onPress={() => router.back()}>
          <MaterialIcons name="arrow-back" size={24} color={theme.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Log Aktivitas</Text>
        {activityLog.length > 0 ? (
          <Pressable style={styles.clearButton} onPress={clearLog}>
            <Text style={styles.clearText}>Hapus</Text>
          </Pressable>
        ) : (
          <View style={{ width: 56 }} />
        )}
      </View>

      {activityLog.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialIcons name="history" size={48} color={theme.textMuted} />
          <Text style={styles.emptyTitle}>Belum Ada Aktivitas</Text>
          <Text style={styles.emptyDesc}>Log aktivitas bot akan muncul di sini</Text>
        </View>
      ) : (
        <FlashList
          data={activityLog}
          renderItem={renderItem}
          estimatedItemSize={70}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 16 }}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  clearButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  clearText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.error,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  emptyDesc: {
    fontSize: 14,
    color: theme.textSecondary,
  },
  logItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
  },
  logIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logMessage: {
    fontSize: 14,
    fontWeight: '500',
    color: theme.textPrimary,
  },
  logDetails: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 2,
  },
  logTime: {
    fontSize: 11,
    color: theme.textMuted,
  },
  separator: {
    height: 1,
    backgroundColor: theme.border,
    marginLeft: 50,
  },
});
