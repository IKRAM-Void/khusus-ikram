import React, { useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeInRight } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';

export default function DashboardScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const {
    botInfo, messages, fetchMessages, isFetchingMessages,
    autoReplyEnabled, autoReplyRules, broadcastIds,
    activityLog, messagesSentCount,
  } = useApp();

  useEffect(() => {
    fetchMessages();
  }, []);

  const onRefresh = useCallback(() => {
    fetchMessages();
  }, [fetchMessages]);

  const menuItems = [
    {
      icon: 'send' as const,
      label: 'Kirim Pesan',
      description: 'Kirim pesan ke Chat ID',
      color: theme.primary,
      onPress: () => router.push('/send-message'),
    },
    {
      icon: 'campaign' as const,
      label: 'Broadcast',
      description: `${broadcastIds.length} penerima tersimpan`,
      color: '#F59E0B',
      onPress: () => router.push('/broadcast'),
    },
    {
      icon: 'history' as const,
      label: 'Log Aktivitas',
      description: `${activityLog.length} entri`,
      color: '#8B5CF6',
      onPress: () => router.push('/activity-log'),
    },
  ];

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isFetchingMessages}
            onRefresh={onRefresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Bot Controller</Text>
            <Text style={styles.headerSubtitle}>Kelola bot Telegram Anda</Text>
          </View>
          <View style={styles.statusPill}>
            <View style={styles.onlineDot} />
            <Text style={styles.statusPillText}>Online</Text>
          </View>
        </View>

        {/* Bot Info Card */}
        <Animated.View entering={FadeInDown.delay(100).duration(500)} style={styles.botCard}>
          <View style={styles.botCardGradient}>
            <View style={styles.botCardHeader}>
              <View style={styles.botAvatar}>
                <MaterialIcons name="smart-toy" size={28} color="#FFF" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.botName}>{botInfo?.first_name || 'Bot'}</Text>
                <Text style={styles.botUsername}>@{botInfo?.username || 'unknown'}</Text>
              </View>
              <View style={styles.botIdBadge}>
                <Text style={styles.botIdText}>ID: {botInfo?.id || '—'}</Text>
              </View>
            </View>
          </View>
        </Animated.View>

        {/* Stats Grid */}
        <Animated.View entering={FadeInDown.delay(200).duration(500)} style={styles.statsGrid}>
          <View style={styles.statCard}>
            <MaterialIcons name="mail" size={22} color={theme.primary} />
            <Text style={styles.statValue}>{messages.length}</Text>
            <Text style={styles.statLabel}>PESAN MASUK</Text>
          </View>
          <View style={styles.statCard}>
            <MaterialIcons name="send" size={22} color={theme.success} />
            <Text style={styles.statValue}>{messagesSentCount}</Text>
            <Text style={styles.statLabel}>TERKIRIM</Text>
          </View>
          <View style={styles.statCard}>
            <MaterialIcons name="reply-all" size={22} color="#F59E0B" />
            <Text style={styles.statValue}>{autoReplyRules.length}</Text>
            <Text style={styles.statLabel}>AUTO REPLY</Text>
          </View>
          <View style={styles.statCard}>
            <MaterialIcons name="group" size={22} color="#8B5CF6" />
            <Text style={styles.statValue}>{broadcastIds.length}</Text>
            <Text style={styles.statLabel}>BROADCAST</Text>
          </View>
        </Animated.View>

        {/* Quick Status */}
        <Animated.View entering={FadeInDown.delay(300).duration(500)} style={styles.section}>
          <View style={styles.quickStatusRow}>
            <View style={[styles.quickStatusCard, autoReplyEnabled && styles.quickStatusActive]}>
              <MaterialIcons
                name={autoReplyEnabled ? 'toggle-on' : 'toggle-off'}
                size={28}
                color={autoReplyEnabled ? theme.success : theme.textMuted}
              />
              <Text style={[styles.quickStatusLabel, autoReplyEnabled && { color: theme.success }]}>
                Auto Reply {autoReplyEnabled ? 'ON' : 'OFF'}
              </Text>
            </View>
            <View style={styles.quickStatusCard}>
              <MaterialIcons name="security" size={28} color={theme.primary} />
              <Text style={styles.quickStatusLabel}>Token Aman</Text>
            </View>
          </View>
        </Animated.View>

        {/* Menu */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>MENU UTAMA</Text>
          {menuItems.map((item, index) => (
            <Animated.View key={item.label} entering={FadeInRight.delay(400 + index * 100).duration(400)}>
              <Pressable
                style={styles.menuItem}
                onPress={() => {
                  Haptics.selectionAsync();
                  item.onPress();
                }}
              >
                <View style={[styles.menuIcon, { backgroundColor: item.color + '18' }]}>
                  <MaterialIcons name={item.icon} size={24} color={item.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  <Text style={styles.menuDesc}>{item.description}</Text>
                </View>
                <MaterialIcons name="chevron-right" size={22} color={theme.textMuted} />
              </Pressable>
            </Animated.View>
          ))}
        </View>

        {/* Recent Messages Preview */}
        {messages.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>PESAN TERBARU</Text>
              <Pressable onPress={() => router.push('/(tabs)/messages')}>
                <Text style={styles.seeAll}>Lihat Semua</Text>
              </Pressable>
            </View>
            {messages.slice(0, 3).map((update, index) => (
              <Animated.View
                key={update.update_id}
                entering={FadeInDown.delay(600 + index * 80).duration(400)}
                style={styles.messagePreview}
              >
                <View style={styles.msgAvatar}>
                  <Text style={styles.msgAvatarText}>
                    {(update.message?.from?.first_name || 'U').charAt(0)}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.msgSender} numberOfLines={1}>
                    {update.message?.from?.first_name || 'Unknown'}
                    {update.message?.from?.username ? ` (@${update.message.from.username})` : ''}
                  </Text>
                  <Text style={styles.msgText} numberOfLines={1}>
                    {update.message?.text || '(no text)'}
                  </Text>
                </View>
                <Text style={styles.msgTime}>
                  {update.message?.date
                    ? new Date(update.message.date * 1000).toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : ''}
                </Text>
              </Animated.View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  headerSubtitle: {
    fontSize: 13,
    color: theme.textSecondary,
    marginTop: 2,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16, 185, 129, 0.12)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: theme.radius.full,
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.success,
  },
  statusPillText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.success,
  },
  botCard: {
    marginHorizontal: 20,
    marginBottom: 16,
    borderRadius: theme.radius.large,
    overflow: 'hidden',
  },
  botCardGradient: {
    backgroundColor: theme.surfaceLight,
    borderWidth: 1,
    borderColor: theme.primary + '30',
    borderRadius: theme.radius.large,
    padding: 20,
  },
  botCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  botAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: theme.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  botName: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  botUsername: {
    fontSize: 14,
    color: theme.telegram,
    marginTop: 2,
  },
  botIdBadge: {
    backgroundColor: theme.surface,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: theme.radius.small,
  },
  botIdText: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 14,
    alignItems: 'center',
    gap: 6,
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  statLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 0.5,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 12,
  },
  seeAll: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.primary,
    marginBottom: 12,
  },
  quickStatusRow: {
    flexDirection: 'row',
    gap: 10,
  },
  quickStatusCard: {
    flex: 1,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 14,
    alignItems: 'center',
    gap: 8,
  },
  quickStatusActive: {
    borderColor: theme.success + '40',
    backgroundColor: 'rgba(16, 185, 129, 0.06)',
  },
  quickStatusLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 16,
    gap: 14,
    marginBottom: 10,
  },
  menuIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  menuDesc: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 2,
  },
  messagePreview: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 14,
    gap: 12,
    marginBottom: 8,
  },
  msgAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  msgAvatarText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
  msgSender: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  msgText: {
    fontSize: 13,
    color: theme.textSecondary,
    marginTop: 2,
  },
  msgTime: {
    fontSize: 11,
    color: theme.textMuted,
  },
});
