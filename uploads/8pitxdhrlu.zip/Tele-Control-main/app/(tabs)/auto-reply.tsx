import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput, Switch,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeOut, Layout } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';

export default function AutoReplyScreen() {
  const insets = useSafeAreaInsets();
  const {
    autoReplyEnabled, toggleAutoReply,
    autoReplyRules, addAutoReplyRule, removeAutoReplyRule, toggleAutoReplyRule,
  } = useApp();

  const [keyword, setKeyword] = useState('');
  const [reply, setReply] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleAdd = async () => {
    if (!keyword.trim() || !reply.trim()) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await addAutoReplyRule(keyword.trim(), reply.trim());
    setKeyword('');
    setReply('');
    setShowForm(false);
  };

  const handleRemove = async (id: string) => {
    Haptics.selectionAsync();
    await removeAutoReplyRule(id);
  };

  const handleToggleRule = async (id: string) => {
    Haptics.selectionAsync();
    await toggleAutoReplyRule(id);
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Auto Reply</Text>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 16 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Master Toggle */}
          <View style={styles.masterToggle}>
            <View style={styles.toggleInfo}>
              <MaterialIcons
                name={autoReplyEnabled ? 'flash-on' : 'flash-off'}
                size={24}
                color={autoReplyEnabled ? theme.success : theme.textMuted}
              />
              <View>
                <Text style={styles.toggleTitle}>Auto Reply</Text>
                <Text style={styles.toggleDesc}>
                  {autoReplyEnabled
                    ? 'Bot akan membalas otomatis berdasarkan keyword'
                    : 'Aktifkan untuk membalas pesan secara otomatis'}
                </Text>
              </View>
            </View>
            <Switch
              value={autoReplyEnabled}
              onValueChange={() => {
                Haptics.selectionAsync();
                toggleAutoReply();
              }}
              trackColor={{ false: theme.border, true: theme.success + '50' }}
              thumbColor={autoReplyEnabled ? theme.success : theme.textMuted}
            />
          </View>

          {/* Add Rule */}
          <Pressable
            style={styles.addButton}
            onPress={() => {
              Haptics.selectionAsync();
              setShowForm(!showForm);
            }}
          >
            <MaterialIcons
              name={showForm ? 'close' : 'add'}
              size={20}
              color={theme.primary}
            />
            <Text style={styles.addButtonText}>
              {showForm ? 'Batal' : 'Tambah Rule Baru'}
            </Text>
          </Pressable>

          {showForm && (
            <Animated.View entering={FadeInDown.duration(300)} style={styles.formCard}>
              <Text style={styles.formLabel}>KEYWORD</Text>
              <TextInput
                style={styles.formInput}
                placeholder="Contoh: halo, info, bantuan"
                placeholderTextColor={theme.textMuted}
                value={keyword}
                onChangeText={setKeyword}
                selectionColor={theme.primary}
              />

              <Text style={[styles.formLabel, { marginTop: 14 }]}>BALASAN OTOMATIS</Text>
              <TextInput
                style={[styles.formInput, styles.formInputMulti]}
                placeholder="Pesan yang akan dikirim sebagai balasan"
                placeholderTextColor={theme.textMuted}
                value={reply}
                onChangeText={setReply}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
                selectionColor={theme.primary}
              />

              <Pressable
                style={[styles.saveButton, (!keyword.trim() || !reply.trim()) && styles.saveDisabled]}
                onPress={handleAdd}
                disabled={!keyword.trim() || !reply.trim()}
              >
                <MaterialIcons name="save" size={18} color="#FFF" />
                <Text style={styles.saveButtonText}>Simpan Rule</Text>
              </Pressable>
            </Animated.View>
          )}

          {/* Rules List */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              RULES ({autoReplyRules.length})
            </Text>

            {autoReplyRules.length === 0 ? (
              <View style={styles.emptyRules}>
                <MaterialIcons name="rule" size={40} color={theme.textMuted} />
                <Text style={styles.emptyText}>Belum ada rule</Text>
                <Text style={styles.emptySubtext}>
                  Tambah rule untuk membalas pesan secara otomatis
                </Text>
              </View>
            ) : (
              autoReplyRules.map((rule, index) => (
                <Animated.View
                  key={rule.id}
                  entering={FadeInDown.delay(index * 80).duration(400)}
                  layout={Layout.springify()}
                  style={[styles.ruleCard, !rule.enabled && styles.ruleDisabled]}
                >
                  <View style={styles.ruleHeader}>
                    <View style={styles.keywordBadge}>
                      <MaterialIcons name="label" size={14} color={theme.primary} />
                      <Text style={styles.keywordText}>{rule.keyword}</Text>
                    </View>
                    <View style={styles.ruleActions}>
                      <Pressable onPress={() => handleToggleRule(rule.id)}>
                        <MaterialIcons
                          name={rule.enabled ? 'toggle-on' : 'toggle-off'}
                          size={28}
                          color={rule.enabled ? theme.success : theme.textMuted}
                        />
                      </Pressable>
                      <Pressable onPress={() => handleRemove(rule.id)}>
                        <MaterialIcons name="delete-outline" size={22} color={theme.error} />
                      </Pressable>
                    </View>
                  </View>
                  <View style={styles.replyPreview}>
                    <MaterialIcons name="reply" size={14} color={theme.textMuted} />
                    <Text style={styles.replyText} numberOfLines={2}>{rule.reply}</Text>
                  </View>
                </Animated.View>
              ))
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  masterToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 16,
    marginBottom: 16,
  },
  toggleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  toggleTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  toggleDesc: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 2,
    maxWidth: 220,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: theme.primary + '15',
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.primary + '30',
    borderStyle: 'dashed',
    paddingVertical: 14,
    marginBottom: 16,
  },
  addButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.primary,
  },
  formCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 16,
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 8,
  },
  formInput: {
    backgroundColor: theme.backgroundSecondary,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 14,
    height: 46,
    color: theme.textPrimary,
    fontSize: 14,
  },
  formInputMulti: {
    height: 90,
    paddingTop: 12,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: theme.primary,
    borderRadius: theme.radius.medium,
    height: 46,
    marginTop: 16,
  },
  saveDisabled: {
    opacity: 0.5,
  },
  saveButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#FFF',
  },
  section: {
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 12,
  },
  emptyRules: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 8,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  emptySubtext: {
    fontSize: 13,
    color: theme.textMuted,
    textAlign: 'center',
  },
  ruleCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 14,
    marginBottom: 10,
  },
  ruleDisabled: {
    opacity: 0.5,
  },
  ruleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  keywordBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: theme.primary + '18',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: theme.radius.small,
  },
  keywordText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.primary,
  },
  ruleActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  replyPreview: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  replyText: {
    flex: 1,
    fontSize: 13,
    color: theme.textSecondary,
    lineHeight: 20,
  },
});
