import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, Switch, TextInput, Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { APP_CONFIG } from '@/constants/config';
import { useApp } from '@/contexts/AppContext';

export default function SettingsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const {
    botInfo, clearToken,
    pinEnabled, pinCode, setPinCode, togglePin,
  } = useApp();

  const [showPinSetup, setShowPinSetup] = useState(false);
  const [newPin, setNewPin] = useState('');

  const handleClearToken = () => {
    Alert.alert(
      'Hapus Token',
      'Token bot akan dihapus dan Anda akan kembali ke halaman setup. Lanjutkan?',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Hapus',
          style: 'destructive',
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            await clearToken();
            router.replace('/setup');
          },
        },
      ]
    );
  };

  const handleChangeToken = () => {
    Alert.alert(
      'Ganti Token',
      'Token saat ini akan dihapus. Anda perlu memasukkan token baru.',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Ganti',
          onPress: async () => {
            await clearToken();
            router.replace('/setup');
          },
        },
      ]
    );
  };

  const handleSetPin = async () => {
    if (newPin.length !== 4) return;
    await setPinCode(newPin);
    if (!pinEnabled) await togglePin();
    setNewPin('');
    setShowPinSetup(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleTogglePin = async () => {
    if (!pinEnabled && !pinCode) {
      setShowPinSetup(true);
      return;
    }
    Haptics.selectionAsync();
    await togglePin();
    if (pinEnabled) {
      await setPinCode(null);
    }
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pengaturan</Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Bot Profile */}
        <Animated.View entering={FadeInDown.delay(100).duration(500)} style={styles.profileCard}>
          <View style={styles.profileAvatar}>
            <MaterialIcons name="smart-toy" size={32} color="#FFF" />
          </View>
          <Text style={styles.profileName}>{botInfo?.first_name || 'Bot'}</Text>
          <Text style={styles.profileUsername}>@{botInfo?.username || 'unknown'}</Text>
          <View style={styles.profileIdRow}>
            <Text style={styles.profileId}>ID: {botInfo?.id || '—'}</Text>
          </View>
        </Animated.View>

        {/* Security Section */}
        <Animated.View entering={FadeInDown.delay(200).duration(500)}>
          <Text style={styles.sectionTitle}>KEAMANAN</Text>

          <View style={styles.settingCard}>
            <Pressable style={styles.settingItem} onPress={handleTogglePin}>
              <View style={[styles.settingIcon, { backgroundColor: theme.primary + '18' }]}>
                <MaterialIcons name="lock" size={22} color={theme.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>PIN Login</Text>
                <Text style={styles.settingDesc}>Kunci aplikasi dengan 4 digit PIN</Text>
              </View>
              <Switch
                value={pinEnabled}
                onValueChange={handleTogglePin}
                trackColor={{ false: theme.border, true: theme.primary + '50' }}
                thumbColor={pinEnabled ? theme.primary : theme.textMuted}
              />
            </Pressable>

            {showPinSetup && (
              <View style={styles.pinSetupSection}>
                <Text style={styles.pinSetupLabel}>Masukkan PIN baru (4 digit)</Text>
                <View style={styles.pinInputRow}>
                  <TextInput
                    style={styles.pinInput}
                    value={newPin}
                    onChangeText={(t) => setNewPin(t.replace(/[^0-9]/g, '').slice(0, 4))}
                    keyboardType="numeric"
                    maxLength={4}
                    secureTextEntry
                    placeholder="••••"
                    placeholderTextColor={theme.textMuted}
                    selectionColor={theme.primary}
                  />
                  <Pressable
                    style={[styles.pinSaveBtn, newPin.length !== 4 && { opacity: 0.5 }]}
                    onPress={handleSetPin}
                    disabled={newPin.length !== 4}
                  >
                    <Text style={styles.pinSaveBtnText}>Simpan</Text>
                  </Pressable>
                </View>
              </View>
            )}

            <View style={styles.settingDivider} />

            <View style={styles.settingItem}>
              <View style={[styles.settingIcon, { backgroundColor: theme.success + '18' }]}>
                <MaterialIcons name="enhanced-encryption" size={22} color={theme.success} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>Enkripsi Token</Text>
                <Text style={styles.settingDesc}>Token terenkripsi di penyimpanan lokal</Text>
              </View>
              <View style={styles.activeBadge}>
                <Text style={styles.activeBadgeText}>Aktif</Text>
              </View>
            </View>
          </View>
        </Animated.View>

        {/* Token Section */}
        <Animated.View entering={FadeInDown.delay(300).duration(500)}>
          <Text style={styles.sectionTitle}>TOKEN</Text>

          <View style={styles.settingCard}>
            <Pressable style={styles.settingItem} onPress={handleChangeToken}>
              <View style={[styles.settingIcon, { backgroundColor: theme.warning + '18' }]}>
                <MaterialIcons name="swap-horiz" size={22} color={theme.warning} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>Ganti Token</Text>
                <Text style={styles.settingDesc}>Gunakan token bot yang berbeda</Text>
              </View>
              <MaterialIcons name="chevron-right" size={22} color={theme.textMuted} />
            </Pressable>

            <View style={styles.settingDivider} />

            <Pressable style={styles.settingItem} onPress={handleClearToken}>
              <View style={[styles.settingIcon, { backgroundColor: theme.error + '18' }]}>
                <MaterialIcons name="delete-forever" size={22} color={theme.error} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.settingLabel, { color: theme.error }]}>Hapus Token</Text>
                <Text style={styles.settingDesc}>Logout dan hapus semua data token</Text>
              </View>
              <MaterialIcons name="chevron-right" size={22} color={theme.textMuted} />
            </Pressable>
          </View>
        </Animated.View>

        {/* About Section */}
        <Animated.View entering={FadeInDown.delay(400).duration(500)}>
          <Text style={styles.sectionTitle}>TENTANG</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingItem}>
              <View style={[styles.settingIcon, { backgroundColor: theme.surfaceHighlight }]}>
                <MaterialIcons name="info" size={22} color={theme.textSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>Versi Aplikasi</Text>
                <Text style={styles.settingDesc}>{APP_CONFIG.name} v{APP_CONFIG.version}</Text>
              </View>
            </View>

            <View style={styles.settingDivider} />

            <View style={styles.settingItem}>
              <View style={[styles.settingIcon, { backgroundColor: theme.surfaceHighlight }]}>
                <MaterialIcons name="code" size={22} color={theme.textSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.settingLabel}>Telegram Bot API</Text>
                <Text style={styles.settingDesc}>api.telegram.org</Text>
              </View>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  profileCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  profileAvatar: {
    width: 72,
    height: 72,
    borderRadius: 24,
    backgroundColor: theme.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  profileName: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  profileUsername: {
    fontSize: 15,
    color: theme.telegram,
    marginTop: 4,
  },
  profileIdRow: {
    marginTop: 10,
    backgroundColor: theme.backgroundSecondary,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: theme.radius.small,
  },
  profileId: {
    fontSize: 12,
    color: theme.textMuted,
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 10,
  },
  settingCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    borderWidth: 1,
    borderColor: theme.border,
    overflow: 'hidden',
    marginBottom: 24,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 14,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  settingDesc: {
    fontSize: 12,
    color: theme.textSecondary,
    marginTop: 2,
  },
  settingDivider: {
    height: 1,
    backgroundColor: theme.border,
    marginLeft: 70,
  },
  activeBadge: {
    backgroundColor: theme.success + '18',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: theme.radius.full,
  },
  activeBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.success,
  },
  pinSetupSection: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  pinSetupLabel: {
    fontSize: 13,
    color: theme.textSecondary,
    marginBottom: 10,
  },
  pinInputRow: {
    flexDirection: 'row',
    gap: 10,
  },
  pinInput: {
    flex: 1,
    backgroundColor: theme.backgroundSecondary,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 14,
    height: 46,
    color: theme.textPrimary,
    fontSize: 20,
    letterSpacing: 8,
    textAlign: 'center',
  },
  pinSaveBtn: {
    backgroundColor: theme.primary,
    borderRadius: theme.radius.medium,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  pinSaveBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFF',
  },
});
