import React, { useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';

export default function MessagesScreen() {
  const insets = useSafeAreaInsets();
  const { messages, fetchMessages, isFetchingMessages } = useApp();

  useEffect(() => {
    fetchMessages();
  }, []);

  const onRefresh = useCallback(() => {
    fetchMessages();
  }, [fetchMessages]);

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const dayMs = 86400000;

    if (diff < dayMs) {
      return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } else if (diff < dayMs * 2) {
      return 'Kemarin';
    }
    return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Pesan Masuk</Text>
        <View style={styles.countBadge}>
          <Text style={styles.countText}>{messages.length}</Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isFetchingMessages}
            onRefresh={onRefresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
      >
        {messages.length === 0 ? (
          <View style={styles.emptyState}>
            <Image
              source={require('@/assets/images/empty-messages.png')}
              style={styles.emptyImage}
              contentFit="contain"
            />
            <Text style={styles.emptyTitle}>Belum Ada Pesan</Text>
            <Text style={styles.emptyDesc}>
              Pesan yang dikirim ke bot Anda akan muncul di sini.{'\n'}
              Tarik ke bawah untuk refresh.
            </Text>
          </View>
        ) : (
          messages.map((update, index) => {
            const msg = update.message;
            if (!msg) return null;

            return (
              <Animated.View
                key={update.update_id}
                entering={FadeInDown.delay(index * 60).duration(400)}
                style={styles.messageCard}
              >
                <View style={styles.msgHeader}>
                  <View style={styles.senderAvatar}>
                    <Text style={styles.avatarText}>
                      {(msg.from?.first_name || 'U').charAt(0).toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.senderName}>
                      {msg.from?.first_name || 'Unknown'}
                      {msg.from?.last_name ? ` ${msg.from.last_name}` : ''}
                    </Text>
                    {msg.from?.username && (
                      <Text style={styles.senderUsername}>@{msg.from.username}</Text>
                    )}
                  </View>
                  <Text style={styles.timeText}>{formatDate(msg.date)}</Text>
                </View>

                <Text style={styles.messageText}>{msg.text || '(media/non-text)'}</Text>

                <View style={styles.msgFooter}>
                  <View style={styles.chatIdBadge}>
                    <MaterialIcons name="tag" size={12} color={theme.textMuted} />
                    <Text style={styles.chatIdText}>Chat ID: {msg.chat.id}</Text>
                  </View>
                  <View style={styles.chatTypeBadge}>
                    <Text style={styles.chatTypeText}>{msg.chat.type}</Text>
                  </View>
                </View>
              </Animated.View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    gap: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  countBadge: {
    backgroundColor: theme.primary,
    borderRadius: theme.radius.full,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  countText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFF',
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 60,
  },
  emptyImage: {
    width: 180,
    height: 180,
    marginBottom: 24,
    borderRadius: 20,
    opacity: 0.8,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.textPrimary,
    marginBottom: 8,
  },
  emptyDesc: {
    fontSize: 14,
    color: theme.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  messageCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 16,
    marginBottom: 10,
  },
  msgHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  senderAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: theme.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 17,
    fontWeight: '700',
    color: '#FFF',
  },
  senderName: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  senderUsername: {
    fontSize: 12,
    color: theme.telegram,
    marginTop: 1,
  },
  timeText: {
    fontSize: 12,
    color: theme.textMuted,
  },
  messageText: {
    fontSize: 15,
    color: theme.textSecondary,
    lineHeight: 22,
    marginBottom: 12,
  },
  msgFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  chatIdBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.backgroundSecondary,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: theme.radius.small,
  },
  chatIdText: {
    fontSize: 11,
    color: theme.textMuted,
    fontWeight: '500',
  },
  chatTypeBadge: {
    backgroundColor: theme.primary + '18',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: theme.radius.small,
  },
  chatTypeText: {
    fontSize: 11,
    color: theme.primary,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
});
