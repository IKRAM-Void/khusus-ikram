import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, Pressable, ScrollView,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import Animated, { FadeInDown, Layout } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { telegramApi } from '@/services/telegramApi';
import { useApp } from '@/contexts/AppContext';

export default function BroadcastScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { broadcastIds, addBroadcastId, removeBroadcastId, addLog, incrementMessagesSent } = useApp();

  const [newId, setNewId] = useState('');
  const [message, setMessage] = useState('');
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [result, setResult] = useState<{ sent: number; failed: number } | null>(null);

  const handleAddId = () => {
    if (!newId.trim()) return;
    Haptics.selectionAsync();
    addBroadcastId(newId.trim());
    setNewId('');
  };

  const handleRemoveId = (id: string) => {
    Haptics.selectionAsync();
    removeBroadcastId(id);
  };

  const handleBroadcast = async () => {
    if (!message.trim() || broadcastIds.length === 0) return;

    Alert.alert(
      'Konfirmasi Broadcast',
      `Kirim pesan ke ${broadcastIds.length} penerima?`,
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Kirim',
          onPress: async () => {
            setIsBroadcasting(true);
            setResult(null);
            let sent = 0;
            let failed = 0;

            for (const id of broadcastIds) {
              const res = await telegramApi.sendMessage(id, message.trim());
              if (res.ok) {
                sent++;
                incrementMessagesSent();
              } else {
                failed++;
              }
            }

            setResult({ sent, failed });
            setIsBroadcasting(false);

            if (sent > 0) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              addLog('broadcast', `Broadcast ke ${sent}/${broadcastIds.length} penerima`, message.trim());
            }
            if (sent > 0) setMessage('');
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.header}>
          <Pressable style={styles.closeButton} onPress={() => router.back()}>
            <MaterialIcons name="close" size={24} color={theme.textSecondary} />
          </Pressable>
          <Text style={styles.headerTitle}>Broadcast</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 24 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Chat IDs Section */}
          <Text style={[styles.sectionTitle, { marginTop: 20 }]}>DAFTAR PENERIMA ({broadcastIds.length})</Text>

          <View style={styles.addIdRow}>
            <View style={styles.addIdInput}>
              <MaterialIcons name="person-add" size={18} color={theme.textMuted} />
              <TextInput
                style={styles.idInput}
                placeholder="Masukkan Chat ID"
                placeholderTextColor={theme.textMuted}
                value={newId}
                onChangeText={setNewId}
                keyboardType="default"
                selectionColor={theme.primary}
              />
            </View>
            <Pressable
              style={[styles.addIdBtn, !newId.trim() && { opacity: 0.5 }]}
              onPress={handleAddId}
              disabled={!newId.trim()}
            >
              <MaterialIcons name="add" size={22} color="#FFF" />
            </Pressable>
          </View>

          {broadcastIds.length > 0 && (
            <View style={styles.idsContainer}>
              {broadcastIds.map((id, index) => (
                <Animated.View
                  key={id}
                  entering={FadeInDown.delay(index * 50).duration(300)}
                  layout={Layout.springify()}
                  style={styles.idChip}
                >
                  <MaterialIcons name="person" size={16} color={theme.primary} />
                  <Text style={styles.idChipText}>{id}</Text>
                  <Pressable onPress={() => handleRemoveId(id)}>
                    <MaterialIcons name="close" size={16} color={theme.error} />
                  </Pressable>
                </Animated.View>
              ))}
            </View>
          )}

          {broadcastIds.length === 0 && (
            <View style={styles.emptyIds}>
              <MaterialIcons name="group-add" size={36} color={theme.textMuted} />
              <Text style={styles.emptyText}>Belum ada penerima</Text>
              <Text style={styles.emptySubtext}>Tambah Chat ID untuk memulai broadcast</Text>
            </View>
          )}

          {/* Message Section */}
          <Text style={[styles.sectionTitle, { marginTop: 24 }]}>PESAN BROADCAST</Text>
          <View style={styles.messageContainer}>
            <TextInput
              style={styles.messageInput}
              placeholder="Ketik pesan broadcast..."
              placeholderTextColor={theme.textMuted}
              value={message}
              onChangeText={setMessage}
              multiline
              numberOfLines={6}
              textAlignVertical="top"
              selectionColor={theme.primary}
            />
          </View>

          {result && (
            <Animated.View entering={FadeInDown.duration(300)} style={styles.resultCard}>
              <View style={styles.resultRow}>
                <View style={styles.resultItem}>
                  <MaterialIcons name="check-circle" size={20} color={theme.success} />
                  <Text style={styles.resultValue}>{result.sent}</Text>
                  <Text style={styles.resultLabel}>Terkirim</Text>
                </View>
                <View style={styles.resultDivider} />
                <View style={styles.resultItem}>
                  <MaterialIcons name="error" size={20} color={theme.error} />
                  <Text style={[styles.resultValue, { color: theme.error }]}>{result.failed}</Text>
                  <Text style={styles.resultLabel}>Gagal</Text>
                </View>
              </View>
            </Animated.View>
          )}

          <Pressable
            style={[
              styles.broadcastButton,
              (isBroadcasting || !message.trim() || broadcastIds.length === 0) && styles.buttonDisabled,
            ]}
            onPress={handleBroadcast}
            disabled={isBroadcasting || !message.trim() || broadcastIds.length === 0}
          >
            {isBroadcasting ? (
              <ActivityIndicator color="#FFF" size="small" />
            ) : (
              <>
                <MaterialIcons name="campaign" size={22} color="#FFF" />
                <Text style={styles.broadcastButtonText}>
                  Broadcast ke {broadcastIds.length} Penerima
                </Text>
              </>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textMuted,
    letterSpacing: 1,
    marginBottom: 12,
  },
  addIdRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 14,
  },
  addIdInput: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 14,
  },
  idInput: {
    flex: 1,
    height: 48,
    color: theme.textPrimary,
    fontSize: 14,
  },
  addIdBtn: {
    width: 48,
    height: 48,
    borderRadius: theme.radius.medium,
    backgroundColor: theme.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  idsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  idChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.full,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  idChipText: {
    fontSize: 13,
    fontWeight: '500',
    color: theme.textPrimary,
  },
  emptyIds: {
    alignItems: 'center',
    paddingVertical: 28,
    gap: 6,
  },
  emptyText: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  emptySubtext: {
    fontSize: 13,
    color: theme.textMuted,
  },
  messageContainer: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 14,
    paddingVertical: 4,
    marginBottom: 16,
  },
  messageInput: {
    height: 130,
    color: theme.textPrimary,
    fontSize: 15,
    paddingTop: 12,
  },
  resultCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 16,
    marginBottom: 16,
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  resultItem: {
    flex: 1,
    alignItems: 'center',
    gap: 6,
  },
  resultValue: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.success,
  },
  resultLabel: {
    fontSize: 12,
    color: theme.textSecondary,
  },
  resultDivider: {
    width: 1,
    height: 40,
    backgroundColor: theme.border,
  },
  broadcastButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#F59E0B',
    borderRadius: theme.radius.medium,
    height: 54,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  broadcastButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFF',
  },
});
