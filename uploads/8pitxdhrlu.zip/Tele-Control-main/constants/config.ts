export const TELEGRAM_API_BASE = 'https://api.telegram.org/bot';

export const STORAGE_KEYS = {
  BOT_TOKEN: '@bot_token_encrypted',
  BOT_INFO: '@bot_info',
  PIN_CODE: '@pin_code',
  PIN_ENABLED: '@pin_enabled',
  AUTO_REPLY_ENABLED: '@auto_reply_enabled',
  AUTO_REPLY_RULES: '@auto_reply_rules',
  BROADCAST_IDS: '@broadcast_chat_ids',
  ACTIVITY_LOG: '@activity_log',
  LAST_UPDATE_ID: '@last_update_id',
};

export const APP_CONFIG = {
  name: 'BotPilot',
  version: '1.0.0',
  splashDuration: 2500,
};
