// Simple XOR-based encryption for token storage
// In production, use a proper encryption library

const ENCRYPTION_KEY = 'B0tP1l0t_S3cur3_K3y_2024';

export function encryptToken(token: string): string {
  let encrypted = '';
  for (let i = 0; i < token.length; i++) {
    const charCode = token.charCodeAt(i) ^ ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length);
    encrypted += String.fromCharCode(charCode);
  }
  return btoa(encrypted);
}

export function decryptToken(encrypted: string): string {
  try {
    const decoded = atob(encrypted);
    let decrypted = '';
    for (let i = 0; i < decoded.length; i++) {
      const charCode = decoded.charCodeAt(i) ^ ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length);
      decrypted += String.fromCharCode(charCode);
    }
    return decrypted;
  } catch {
    return '';
  }
}
