import { TELEGRAM_API_BASE } from '@/constants/config';

export interface BotInfo {
  id: number;
  is_bot: boolean;
  first_name: string;
  username: string;
  can_join_groups: boolean;
  can_read_all_group_messages: boolean;
  supports_inline_queries: boolean;
}

export interface TelegramMessage {
  message_id: number;
  from: {
    id: number;
    is_bot: boolean;
    first_name: string;
    last_name?: string;
    username?: string;
  };
  chat: {
    id: number;
    first_name?: string;
    last_name?: string;
    username?: string;
    type: string;
  };
  date: number;
  text?: string;
}

export interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

class TelegramAPI {
  private token: string = '';

  setToken(token: string) {
    this.token = token;
  }

  getToken() {
    return this.token;
  }

  private getBaseUrl() {
    return `${TELEGRAM_API_BASE}${this.token}`;
  }

  async verifyToken(token?: string): Promise<{ ok: boolean; result?: BotInfo; error?: string }> {
    const useToken = token || this.token;
    try {
      const response = await fetch(`${TELEGRAM_API_BASE}${useToken}/getMe`);
      const data = await response.json();
      if (data.ok) {
        return { ok: true, result: data.result };
      }
      return { ok: false, error: data.description || 'Invalid token' };
    } catch (error: any) {
      return { ok: false, error: error.message || 'Network error' };
    }
  }

  async sendMessage(chatId: string, text: string, parseMode?: string): Promise<{ ok: boolean; error?: string }> {
    try {
      const body: any = { chat_id: chatId, text };
      if (parseMode) body.parse_mode = parseMode;
      
      const response = await fetch(`${this.getBaseUrl()}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await response.json();
      if (data.ok) {
        return { ok: true };
      }
      return { ok: false, error: data.description || 'Failed to send message' };
    } catch (error: any) {
      return { ok: false, error: error.message || 'Network error' };
    }
  }

  async getUpdates(offset?: number, limit: number = 100): Promise<{ ok: boolean; result?: TelegramUpdate[]; error?: string }> {
    try {
      const params = new URLSearchParams();
      if (offset !== undefined) params.append('offset', String(offset));
      params.append('limit', String(limit));
      
      const response = await fetch(`${this.getBaseUrl()}/getUpdates?${params.toString()}`);
      const data = await response.json();
      if (data.ok) {
        return { ok: true, result: data.result };
      }
      return { ok: false, error: data.description || 'Failed to get updates' };
    } catch (error: any) {
      return { ok: false, error: error.message || 'Network error' };
    }
  }

  async deleteWebhook(): Promise<{ ok: boolean; error?: string }> {
    try {
      const response = await fetch(`${this.getBaseUrl()}/deleteWebhook`);
      const data = await response.json();
      return { ok: data.ok, error: data.description };
    } catch (error: any) {
      return { ok: false, error: error.message };
    }
  }
}

export const telegramApi = new TelegramAPI();
