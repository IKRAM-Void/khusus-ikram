global.prefix = [".","!","/"]
global.publik = false;
global.owner = ["6285785256009"];
global.namabot = 'Kaito Invictus';
global.dana = "083807828613";
global.ovo = "085785256009";
global.gopay = "085785256009";
global.qris = "-";
global.egg = "15";
global.loc = "1";
global.domain = "";
global.apikey = "";
global.capikey = "";

global.mess = { 
  owner: `• Fitur Khusus Owner!`,
  premium: `• Fitur Khusus Premium!`,
  succes: `• Successfull!`,
};