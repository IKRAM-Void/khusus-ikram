require('./setting');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  jidDecode,
  proto
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk');
const readline = require("readline");
const { smsg, fetchJson, sleep } = require('./lib/function');
const fs = require("fs");
const fetch = require("node-fetch");
const { makeInMemoryStore } = require("@whiskeysockets/baileys");
const store = makeInMemoryStore({ logger: pino().child({ level: "silent", stream: 'store' }) });
const usePairingCode = true;

async function Startsock() {
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const sock = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: !usePairingCode,
    auth: state,
    browser: ["Ubuntu", "Chrome", "20.0.04"]
  });

  if (usePairingCode && !sock.authState.creds.registered) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(`
=> Enter Your Number
`, async (phoneNumber) => {
      const cleanNumber = phoneNumber.trim();
      console.log(`
=> Process Integration Your Number
`);

      setTimeout(async () => {
        console.log(`
=> Your Number Connect Process ✅
`);
        const code = await sock.requestPairingCode(cleanNumber);
        console.log(`
=> Your Pairing Code : [ ${code} ]
`);
        rl.close();
      }, 2500);
    });
  }

  sock.public = global.publik;
  
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const reconnect = () => Startsock();
      const reasons = {
        [DisconnectReason.badSession]: "Hapus Session Terus Run Ulang!",
        [DisconnectReason.connectionClosed]: "Connection Closed, Reconnecting...",
        [DisconnectReason.connectionLost]: "Koneksi Terputus Dari Server, Menghubungkan Ulang...",
        [DisconnectReason.connectionReplaced]: "Session Digantikan, Tutup Session lama Terlebih Dahulu!",
        [DisconnectReason.loggedOut]: "Logged Out, Run Ulang!",
        [DisconnectReason.restartRequired]: "Please Waiting...",
        [DisconnectReason.timedOut]: "Koneksi Timeout, Menghubungkan Ulang..."
      };
      console.log(reasons[reason] || `Unknown DisconnectReason: ${reason}`);
      reconnect();
    }

    if (connection === "open") {
      console.log(chalk.green.bold(`╭─¤
│ Successfully Connected To Server ✅
╰─¤`));
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    try {
      const msg = messages[0] || messages[messages.length - 1];
      if (type !== "notify") return;
      if (!msg?.message) return;
      if (msg.key && msg.key.remoteJid == "status@broadcast") return;
      const m = smsg(sock, msg, store);
      require("./kaito")(sock, m, msg, store);
    } catch (err) {
      console.log(err);
    }
  });

  sock.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return (decode.user && decode.server && decode.user + '@' + decode.server) || jid;
    } else return jid;
  };

  sock.sendText = (jid, text, quoted = '', options) => sock.sendMessage(jid, { text: text, ...options }, { quoted });

  sock.ev.on('contacts.update', update => {
    for (let contact of update) {
      let id = sock.decodeJid(contact.id);
      if (store && store.contacts) {
        store.contacts[id] = { id, name: contact.notify };
      }
    }
  });

  sock.ev.on('creds.update', saveCreds);
  return sock;
}

Startsock();